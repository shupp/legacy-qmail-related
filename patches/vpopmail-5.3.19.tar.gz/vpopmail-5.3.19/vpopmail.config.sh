./configure \
 --enable-file-sync=n \
 --enable-auth-logging=y \

