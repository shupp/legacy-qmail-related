#!/bin/bash
#
# ****************************************************************
# * Make SURE you backup your vpasswd files before running this! *
# ****************************************************************
#
#  If your vpopmail install only uses one /etc/passwd entry, and vpopmail
#  is installed in /home/vpopmail, this should work as is.  If vpopmail is
#  installed elsewhere, you'll need to edit DOAMINSDIR and VPOPMAILBIN below.
#
#  This is only relevant to the cdb module of vpopmail. See FAQ #5 for details
#
#  Bill Shupp <hostmaster@shupp.org>




DOMAINSDIR="/home/vpopmail/domains"
VPOPMAILBIN="/home/vpopmail/bin"

for d in `ls $DOMAINSDIR` ; do
	VPASSWD="$DOMAINSDIR/$d/vpasswd"
	if [ -f "$VPASSWD" ] ; then
		echo "converting $d ..."
		for u in `cat $VPASSWD | awk -F: '{ print $1 }'` ; do
			$VPOPMAILBIN/vmoduser -C "" $u@$d
		done
	fi
done
