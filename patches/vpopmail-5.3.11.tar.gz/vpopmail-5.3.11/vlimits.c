/*
 * vlimits.c
 * handle domain limits in both file format
 * Brian Kolaci <bk@galaxy.net>
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>
#include "config.h"
#include "vlimits.h"
#include "vpopmail.h"


#ifndef ENABLE_MYSQL_LIMITS

#define TOKENS " :\t\n\r"

/* find/read the .qmailadmin-limits file */
int vget_limits( char *domain, struct vlimits *limits )
{
    char buf[256];
    char dir[MAXPATHLEN];
    uid_t uid;
    gid_t gid;
    char * s1;
    char * s2;
    FILE * fs;

    /* initialize structure */
    memset(limits, 0, sizeof(*limits));
    limits->maxpopaccounts = -1;
    limits->maxaliases = -1;
    limits->maxforwards = -1;
    limits->maxautoresponders = -1;
    limits->maxmailinglists = -1;
    limits->diskquota = 0;
    limits->defaultquota = ""; 
    limits->disablepop = 0;
    limits->disableimap = 0;
    limits->disabledialup = 0;
    limits->disablepasswordchanging = 0;
    limits->disablerelay = 0;
    limits->disablesmtp = 0;
    limits->disablewebmail = 0;

    /* get filename */
    vget_assign(domain, dir, sizeof(dir), &uid, &gid);
    strncat(dir, "/.qmailadmin-limits", sizeof(dir));

    /* open file */
    if ((fs = fopen(dir, "r")) != NULL) {
  while (fgets(buf, sizeof(buf), fs) != NULL) {
      if ((s1 = strtok(buf, TOKENS)) == NULL)
      continue;

      if (!strcmp(s1, "maxpopaccounts")) {
          if ((s2 = strtok(buf, TOKENS)) == NULL)
          continue;
      limits->maxpopaccounts = atoi(s2);
      }

      if (!strcmp(s1, "maxaliases")) {
          if ((s2 = strtok(buf, TOKENS)) == NULL)
          continue;
      limits->maxaliases = atoi(s2);
      }

      if (!strcmp(s1, "maxforwards")) {
          if ((s2 = strtok(buf, TOKENS)) == NULL)
          continue;
      limits->maxforwards = atoi(s2);
      }

      if (!strcmp(s1, "maxautoresponders")) {
          if ((s2 = strtok(buf, TOKENS)) == NULL)
          continue;
      limits->maxautoresponders = atoi(s2);
      }

      if (!strcmp(s1, "maxmailinglists")) {
          if ((s2 = strtok(buf, TOKENS)) == NULL)
          continue;
      limits->maxmailinglists = atoi(s2);
      }

      if (!strcmp(s1, "quota")) {
          if ((s2 = strtok(buf, TOKENS)) == NULL)
          continue;
      limits->diskquota = atoi(s2);
      }

      if (!strcmp(s1, "default_quota")) {
          if ((s2 = strtok(buf, TOKENS)) == NULL)
          continue;
      limits->defaultquota = format_maildirquota(s2);
      }

      if (!strcmp(s1, "disable_pop")) {
      limits->disablepop = 1;
      }

      if (!strcmp(s1, "disable_imap")) {
      limits->disableimap = 1;
      }

      if (!strcmp(s1, "disable_dialup")) {
      limits->disabledialup = 1;
      }

      if (!strcmp(s1, "disable_password_changing")) {
      limits->disablepasswordchanging = 1;
      }

      if (!strcmp(s1, "disable_external_relay")) {
      limits->disablerelay = 1;
      }

      if (!strcmp(s1, "disable_smtp")) {
      limits->disablesmtp = 1;
      }

      if (!strcmp(s1, "disable_webmail")) {
      limits->disablewebmail = 1;
      }
  }
  fclose(fs);
  chown(dir,uid,gid);
  chmod(dir, S_IRUSR|S_IWUSR);
    } else {
  fprintf(stderr, "vlimits: failed to open limits file (%d):  %s\n", errno, dir);
  return -1;
    }

    return 0;
}

int vset_limits( char *domain, struct vlimits *limits )
{
    char dir[256];
    uid_t uid;
    gid_t gid;
    FILE * fs;

    /* get filename */
    vget_assign(domain, dir, sizeof(dir), &uid, &gid);
    strncat(dir, "/.qmailadmin-limits", sizeof(dir));

    /* open file */
    if ((fs = fopen(dir, "w+")) != NULL) {
  fprintf(fs, "maxpopaccounts: %d\n", limits->maxpopaccounts);
  fprintf(fs, "maxaliases: %d\n", limits->maxaliases);
  fprintf(fs, "maxforwards: %d\n", limits->maxforwards);
  fprintf(fs, "maxautoresponders: %d\n", limits->maxautoresponders);
  fprintf(fs, "maxmailinglists: %d\n", limits->maxmailinglists);
  fprintf(fs, "quota: %d\n", limits->diskquota);
  fprintf(fs, "default_quota: %s\n", limits->defaultquota);
  if (limits->disablepop)
      fprintf(fs, "disable_pop\n");
  if (limits->disableimap)
      fprintf(fs, "disable_imap\n");
  if (limits->disabledialup)
      fprintf(fs, "disable_dialup\n");
  if (limits->disablepasswordchanging)
      fprintf(fs, "disable_password_changing\n");
  if (limits->disablewebmail)
      fprintf(fs, "disable_webmail\n");
  if (limits->disablerelay)
      fprintf(fs, "disable_external_relay\n");
  if (limits->disablesmtp)
      fprintf(fs, "disable_smtp\n");
  fclose(fs);
    } else {
  fprintf(stderr, "vlimits: failed to open limits file (%d):  %s\n", errno, dir);
  return -1;
    }

    return 0;
}

int vdel_limits( char *domain )
{
    char dir[256];
    uid_t uid;
    gid_t gid;

    /* get filename */
    vget_assign(domain, dir, sizeof(dir), &uid, &gid);
    strncat(dir, "/.qmailadmin-limits", sizeof(dir));
    return unlink(dir);
}

#endif

