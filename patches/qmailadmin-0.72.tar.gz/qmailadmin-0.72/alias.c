/* QmailAdmin 
 * Copyright (C) 1999 Inter7 Internet Technologies, Inc. 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <unistd.h>
#include <pwd.h>
#include <errno.h>
#include <dirent.h>
#include <vpopmail.h>
#include <vauth.h>
#include "config.h"
#include "qmailadmin.h"
#include "qmailadminx.h"

char* dotqmail_alias_command(char* command);

show_aliases()
{
	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}
	send_template( "show_alias.html" );
}


show_dotqmail_lines(char *user, char *dom, time_t mytime, char *dir, char *dottype)
{
 DIR *mydir;
 struct dirent *mydirent;
 FILE *fs;
 char alias_user[MAX_FILE_NAME];
 char alias_name[MAX_FILE_NAME];
 char *alias_name_from_command;
 int i,j,stop,k,startnumber;

    if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
        	exit(0);
    }
    if (atoi(Pagenumber)==0) {
	    *Pagenumber='1';
    }
	startnumber = MAXALIASESPERPAGE * (atoi(Pagenumber) - 1);
	k=0;
	if ( (mydir = opendir(".")) == NULL ) {
		fprintf(actout,"%s %d<BR>\n", get_html_text("143"), 1);
		fprintf(actout,"</table>");
		return(0);
	}

	while( (mydirent=readdir(mydir)) != NULL ) {

		/* don't read files that are really ezmlm-idx listowners,
		i.e.   qmail-user-owner */
		if ( strncmp(".qmail-", mydirent->d_name, 7) == 0 && 
			( strstr(mydirent->d_name, ".qmail-owner") != NULL || 
				strstr(mydirent->d_name, "-owner") == NULL )) {

			if ( k < startnumber ) {
				k++; 
				continue;
			}
			if ( k >MAXALIASESPERPAGE + startnumber) {
				break;
			}

			if ( (fs=fopen(mydirent->d_name,"r"))==NULL) {
				fprintf(actout,"%s %s<br>\n", get_html_text("144"),
					mydirent->d_name);
				fclose(fs);
				continue;
			}
			memset(TmpBuf2,0,MAX_BUFF);
			fgets( TmpBuf2, MAX_BUFF, fs);
			alias_name_from_command = dotqmail_alias_command(TmpBuf2);
			if ( alias_name_from_command != NULL ) {
                        	
				/* first case checks if the file beginnning is an email
			 	 * and the function is not being called to display forwards,
			 	 * the second case checks if the file beginning is an user, and
			 	 * the type is not an alias 
			 	 */
                        	
				if ((strstr(alias_name_from_command,"@")!=NULL) && 
						(strcmp(dottype, "forward"))) {
					fclose(fs);
					continue; 
				} else if ((strstr(alias_name_from_command,"@")==NULL) && 
							(strcmp(dottype, "alias"))) {
					fclose(fs);
					continue;
				}
			
				for(i=7,j=0;j<MAX_FILE_NAME-1&&mydirent->d_name[i]!=0;++i,++j) {
					alias_name[j] = mydirent->d_name[i];
					if ( alias_name[j] == ':' ) alias_name[j] = '.';
				}
				alias_name[j] = 0;
				stop=0;

				fprintf(actout, "<TR><TD>%s</TD><TD align=center>", alias_name);
				while (stop == 0) {
					alias_name_from_command = dotqmail_alias_command(TmpBuf2);
				
					/* check to see if it is an invalid line , 
					 * if so skip to next
					 */
					if (alias_name_from_command == NULL ) {
						if (fgets(TmpBuf2, 500, fs)==NULL) { 
							stop=1;
						}
						continue;
					}
					
					strcpy(alias_user, alias_name_from_command);
				
					if (fgets(TmpBuf2, 500, fs) == NULL) {
						stop=1;
						fprintf(actout, "%s ", alias_user);
					} else {
						fprintf(actout, "%s, ", alias_user);
					}
				}

				fprintf(actout, "</TD>");

        		fprintf(actout,"<TD align=center><A href=%s/com/moddotqmail?atype=%s&user=%s&dom=%s&time=%d&modu=%s>\
	<img src=\"/images/qmailadmin/delete.gif\" border=0></a></TD>",
                CGIPATH,dottype, user, dom, mytime, alias_name);
        		fprintf(actout,"<TD align=center><A href=%s/com/deldotqmail?atype=%s&user=%s&dom=%s&time=%d&modu=%s>\
	<img src=\"/images/qmailadmin/delete.gif\" border=0></a></TD>",
                CGIPATH,dottype, user, dom, mytime, alias_name);
	
			}
			fclose(fs);
			k++;
		}
	}
	closedir(mydir);

	fprintf(actout,"<tr><td colspan=5><center>\n");
	if ( AdminType==SYSTEM_ADMIN || AdminType==DOMAIN_ADMIN ) {
	 char *type;

		if( strcmp(dottype,"forward") == 0 ){
			type = "showforwards";
		} else {
			type = "showaliases";
		}
		fprintf(actout,"<A href=%s/com/%s?atype=%s&user=%s&dom=%s&time=%d&page=%d>\
			%s&nbsp;</A>\n",
				CGIPATH,type,dottype, user, dom,mytime,
				atoi(Pagenumber)-1 ? atoi(Pagenumber)-1 : atoi(Pagenumber), 
				get_html_text("135"));
		fprintf(actout,"<a href=%s/com/%s?atype=%s&user=%s&dom=%s&time=%d&page=%s>\
			%s&nbsp</a>&nbsp;",
				CGIPATH,type, dottype, user,dom,mytime,Pagenumber, 
				get_html_text("136"));
		fprintf(actout,"<A href=%s/com/%s?atype=%s&user=%s&dom=%s&time=%d&page=%d>\
			%s</A>\n",
				CGIPATH,type,dottype, user, dom,mytime,atoi(Pagenumber)+1, 
				get_html_text("137"));	
	}
	fprintf(actout,"</td></tr><BR>\n");									
}

/* This Function shows the inside of a .qmail file,
with the edit mode */

show_dotqmail_file(char *user) 
{
 FILE *fs;
 char alias_user[MAX_FILE_NAME];
 char *alias_name_from_command;
 char *dot_file;
 int l,j;

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}
	
	l = strlen(user);
	dot_file= strcat(strcpy(malloc(8 + l), ".qmail-"), user);

	for(j=8;dot_file[j]!=0;j++) {
		if (dot_file[j]=='.') {
			dot_file[j] = ':';
		}
	}

	if ( (fs=fopen(dot_file,"r"))==NULL) {
		sprintf(StatusMessage,"%s %s<br>\n", get_html_text("144"),
			dot_file);
		vclose();
		exit(0);
	}
				
	fprintf(actout, 
		"<TR><TD align=middle><b>%s</b></TD><TD>&nbsp;</TD><TD>&nbsp;</TD></TR>", user);
	memset(TmpBuf2,0,MAX_BUFF);

	while( fgets( TmpBuf2, MAX_BUFF, fs) != NULL ) {
		alias_name_from_command = dotqmail_alias_command(TmpBuf2);
                        
		/* check to see if it is an invalid line , if so skip to next*/
		if (alias_name_from_command == NULL ) continue;

		strcpy(alias_user, alias_name_from_command);
				
		fprintf(actout, "<TR><TD>&nbsp;</TD><TD align=middle>%s</TD>", alias_user);

		fprintf(actout,
 "<TD align=middle>\n<form method=post name=moddotqmail action=%s/com/moddotqmailnow>\n\
  <input type=hidden name=user value=%s>\n \
  <input type=hidden name=dom value=%s>\n \
  <input type=hidden name=time value=%i>\n \
  <input type=hidden name=modu value=%s>\n \
  <input type=hidden name=linedata value=\"%s\">\n \
  <input type=hidden name=action value=\"delentry\">\n \
  <input type=image border=0 src=\"/images/qmailadmin/delete.gif\"> \n \
  </form></TD></TR>",
			CGIPATH, Username, Domain, Mytime,user, TmpBuf2);
			
	}
   	fclose(fs);
}

int onevalidonly(char *user) {
 FILE *fs;
 char *alias_name_from_command;
 char *dot_file;
 int l,j;

	l = strlen(user);
	dot_file= strcat(strcpy(malloc(8 + l), ".qmail-"), user);
	for(j=8;dot_file[j]!=0;j++) {
		if (dot_file[j]=='.') {
			dot_file[j] = ':';
		}
	}

	if ( (fs=fopen(dot_file,"r"))==NULL) {
		sprintf(StatusMessage,"%s %s<br>\n", get_html_text("144"),
			dot_file);
		vclose();
		exit(0);
	}
			
	j=0;
	while( fgets( TmpBuf2, MAX_BUFF, fs) != NULL ) {
		alias_name_from_command = dotqmail_alias_command(TmpBuf2);
		/* check to see if it is an invalid line , if so skip to next */
		if (alias_name_from_command == NULL ) continue;
        
		j++;
	}
	fclose(fs);

	if (j <2 ) {
		return (1);
	} else {
		return (0);
	}

}



moddotqmail()
{
	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}
	send_template("mod_dotqmail.html");
}

moddotqmailnow() 
{
 struct vqpasswd *pw;

	if ( strcmp(ActionUser,"default")==0) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	if (strcmp(Action,"delentry")==0) {
		if (onevalidonly(ActionUser) ) {
			sprintf(StatusMessage, "%s\n", get_html_text("149"));
			moddotqmail();
		vclose();
			exit(0);
		}
		
		if (dotqmail_del_line(ActionUser,LineData) ) {
			sprintf(StatusMessage, "%s %d\n", get_html_text("150"), 1);
			moddotqmail();
		vclose();
			exit(0);
		}
		sprintf(StatusMessage, "%s\n", get_html_text("151") );
		moddotqmail();
		vclose();
		exit(0);
	
	} else if (strcmp(Action,"addremote")==0) {
		if (check_email_addr(Newu) ) {
			sprintf(StatusMessage, "%s %s\n", get_html_text("148"), Newu);
			moddotqmail();
		vclose();
			exit(0);
		}
		sprintf(TmpBuf2, "&%s\n",Newu);
	
		if (dotqmail_add_line(ActionUser,TmpBuf2)) {
			sprintf(StatusMessage, "%s %d\n", get_html_text("150"), 2);
			moddotqmail();
		vclose();
			exit(0);
		}
		fprintf(actout,"%s %s\n", get_html_text("152"),Newu);
		moddotqmail();
		vclose();
		exit(0);
	
	} else if (strcmp(Action,"addlocal")==0) {
		if ( !vauth_getpw(Newu, Domain) ) {
			sprintf(StatusMessage, "%s %s\n", Newu, get_html_text("153"));
			moddotqmail();
		vclose();
			exit(0);
		}
		pw = vauth_getpw( Newu, Domain );		
		sprintf(TmpBuf2, "%s/Maildir/\n",pw->pw_dir);
	                                                                
		if (dotqmail_add_line(ActionUser,TmpBuf2)) {
			sprintf(StatusMessage, "%s %d\n", get_html_text("150"), 3);
			moddotqmail();
		vclose();
			exit(0);
		}
		sprintf(StatusMessage, "%s %s\n", Newu, get_html_text("154"));
		moddotqmail();
		vclose();
		exit(0);
	} else {
		sprintf(StatusMessage, "%s\n", get_html_text("155"));
		vclose();
		exit(0);
	}
}

adddotqmail()
{

	if (!(strcmp(AliasType, "alias"))) {
		count_aliases();
		load_limits();
		if ( MaxAliases != -1 && CurAliases >= MaxAliases ) {
			fprintf(actout, "%s %d\n",  
				get_html_text("156"), MaxAliases);
			show_menu();
		vclose();
			exit(0);
		}
		send_template( "add_alias.html" );
	} else if (!(strcmp(AliasType, "forward"))) {
        count_forwards();
        load_limits();
		if ( MaxForwards != -1 && CurForwards >= MaxForwards ) {
			fprintf(actout, "%s %d\n", 
				get_html_text("157"), MaxForwards);
			show_menu();
		vclose();
     		exit(0);
        }
        send_template( "add_forward.html" );

	} else {	
		fprintf(actout, "%s\n", get_html_text("159"));
		show_menu();
		vclose();
		exit(0);
	}
}


adddotqmailnow()
{
 struct vqpasswd *pw;
 int err;

	if (AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN && 
		!(AdminType==USER_ADMIN && strcmp(ActionUser, Username)==0)) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	err = 0;

	/* check to see if we already have a user with this name */
	if (err = fixup_local_name(Alias))
		sprintf(StatusMessage, "%s %s\n", get_html_text("160"), Alias);

	if (!(strcmp(AliasType, "alias")) && !err ) {
		if (!err && (err = (vauth_getpw( ActionUser, Domain ) == NULL)))
			sprintf(StatusMessage, "%s\n", get_html_text("161"));
		} else if (!(strcmp(AliasType, "forward")) && !err) {
			if (err = ( check_email_addr(ActionUser)) ) {
				sprintf(StatusMessage, "%s %s\n", get_html_text("162"), 
					ActionUser);
        } else if ( err = (strlen(Alias)<=0) ) {
                sprintf(StatusMessage, "%s %s\n", get_html_text("163"), Alias);
        } else if (err = ( fixup_local_name(Alias)) ) {
                sprintf(StatusMessage, "%s %s\n", get_html_text("163"), Alias);
        }
	} else if (!err) {
		err=1;
		sprintf(StatusMessage, "%s\n", get_html_text("164")); 
	}

	if (err) {
		adddotqmail();
		vclose();
		exit(0);
	}

	if (!err) {
	  	if  (!(strcmp(AliasType, "alias"))) {
			pw = vauth_getpw( ActionUser, Domain );
			sprintf(TmpBuf2, "%s/Maildir/\n", pw->pw_dir);
			dotqmail_add_line(Alias, TmpBuf2);
		} else if  (!(strcmp(AliasType, "forward"))) {
			sprintf(TmpBuf2, "&%s\n", ActionUser);
			dotqmail_add_line(Alias, TmpBuf2);
		} else { 
			err=1; 
		}
	}

	if (err) {
		sprintf(StatusMessage, "%s %s %s %s\n", get_html_text("165"), 
			AliasType, Alias, ActionUser);
	} else {
		sprintf(StatusMessage, "%s %s %s %s\n", get_html_text("166"), 
			AliasType, Alias, ActionUser);
	}
	show_menu(Username, Domain, Mytime);
}

deldotqmail()
{

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}


	if (!(strcmp(AliasType, "alias"))) {
		send_template( "del_alias_confirm.html" );
	} else if (!(strcmp(AliasType, "forward"))) {
		send_template( "del_forward_confirm.html" );
	} else {
		sprintf(StatusMessage, "%s\n", get_html_text("164")); 
		show_menu(Username, Domain, Mytime);
	}
}

deldotqmailnow()
{

	if (AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN && 
		!(AdminType==USER_ADMIN && !strcmp(ActionUser, Username))) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		show_menu(Username, Domain, Mytime);
		vclose();
		exit(0);
	}


	/* check to see if we already have a user with this name */
	if (fixup_local_name(ActionUser)) {
		sprintf(StatusMessage,"%s %s\n", get_html_text("160"), Alias);
		deldotqmail();
		vclose();
		exit(0);
	}

	if (!(dotqmail_delete_files(ActionUser))) {
		sprintf(StatusMessage, "%s %s %s\n", get_html_text("167"), 
			Alias, ActionUser);
	} else {
		sprintf(StatusMessage, "%s %s %s\n", get_html_text("168"), 
			Alias, ActionUser);
	}
	show_menu(Username, Domain, Mytime);
}

count_aliases()
{
 DIR *mydir;
 struct dirent *mydirent;
 FILE *fs;
 char *alias_name_from_command;

	/* FIXME: Do some caching here. */

	CurAliases = 0;
	if ( (mydir = opendir(".")) == NULL ) {
		fprintf(actout,"%s %s<br>\n", get_html_text("144"),
			"1");
		fprintf(actout, "</table>");
		return(0);
	}

	while( (mydirent=readdir(mydir)) != NULL ) {
		if ( strncmp(".qmail-", mydirent->d_name, 7) == 0 ) {
			if ( (fs=fopen(mydirent->d_name,"r"))==NULL) {
				fprintf(actout,"%s %s<br>\n", get_html_text("144"),
					mydirent->d_name);
				continue;
			}
			memset(TmpBuf2,0,MAX_BUFF);
			fgets( TmpBuf2, 500, fs);
			alias_name_from_command = dotqmail_alias_command(TmpBuf2);
			if ( alias_name_from_command != NULL ) {
				if (strstr(alias_name_from_command,"@")==NULL) {
					++CurAliases;
				}
			}
			fclose(fs);
		}
	}
	closedir(mydir);
}


char* dotqmail_alias_command(char* command)
{
 int len;
 static char user[501];
 char* s;

	if (command == NULL) return NULL;

	len=0;
	while( command[len]!=0 && isspace(command[len])==0 ) ++len;
	command[len] = 0;

	
	if ( (command[len - 1] == '/') && (command[0] == '/' ) || 
		 (command[0] == '.') ) { 

		strcpy(user, command); user[len - 1] = '\0';

        if ((s = strrchr(user, '/')) == NULL) return NULL;
        if (strcmp(s, "/Maildir") != 0) return NULL;

        *s = '\0';
        if ((s = strrchr(user, '/')) == NULL) return NULL;

        return (s+1);
        
	} else if ( !check_email_addr( (command+1) ) ){
		strcpy(user, command); 
		s = user;	
		*s = '\0';

		if (command[0] == '&' ) {
			return (s+1);
		} else {
			return (command);
		}
	} else {
		return NULL;
	}
}
