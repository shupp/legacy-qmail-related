Using PDFlib on EBCDIC platforms
================================

Important note: the Aladdin license does not apply to PDFlib on
EBCDIC platforms. This means you will have to purchase a commercial
PDFlib license in order to use PDFlib on AS/400, S/390, or other
EBCDIC-based platforms.

PDFlib can be used on EBCDIC-based midrange and mainframe platforms
such as IBM AS/400 and S/390. PDF generation on EBCDIC systems is a
delicate issue since PDF is based on ASCII operators, but nevertheless
we want to be able to process EBCDIC text strings. However, PDFlib is
carefully set up to meet these requirements.

Note that although the PDFlib core library C code is fully EBCDIC-aware,
not all language bindings have been modified for use on EBCDIC-based hosts.
Currently only the C, C++, RPG, and Java language can be used on
EBCDIC platforms.

Please observe the notes in the PDFlib manual regarding expected
file formats (EBCDIC text vs. binary) for several items related to
PDFlib usage. These rules must strictly be observed in order to
successfully use PDFlib on EBCDIC-based platforms.

Pre-built PDFlib libraries for IBM eServer iSeries 400 and zSeries 390
are available from our Web site.
