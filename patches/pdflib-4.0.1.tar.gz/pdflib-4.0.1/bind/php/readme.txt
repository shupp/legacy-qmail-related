Notes on the PDFlib PHP binding

Overview
========

With the binary distribution of PDFlib you have one main way how to use PDFlib
with PHP by using the supplied loadable module. This implies some restrictions,
but simplifies PDFlib deployment a lot. 

If the loadable module does not fit your needs, the binary distribution 
also includes a precompiled PDFlib library (libpdf.*), to be used in your
custom build process for PHP. This will allow you to integrate PDFlib
(including the PDI functionality) into your own PHP build process.

Please note that the binary distribution is for commercial licensing only.
If you want to use the PDF import library PDI you _must_ use the binary
distribution since PDI is not available in source form.

Of course you may also use PDFlib for PHP with the source distribution, but
since there are so many PHP configuration options we will only give a rough
overview how to do this.

Summary:

- "Loadable Module"
  The recommended way for using PDFlib with PHP.

- "Rebuild PHP"
  If the loadable module does not fit your needs you can rebuild PHP with
  PDFlib support, but this requires more effort than the loadable module.

- "Fonts"
  Explains how to integrate your own fonts to be used with PDFlib

- "Samples"
  How to set up the supplied PDFlib examples.


Loadable Module
===============

Use the PDFlib loadable module from the "bind/php/<phpversion>" directory
of the PDFlib binary distribution. The name of the loadable module depends
on the platform:

    - Windows: php_pdf.dll
    - Linux: libpdf_php.so
    - Other Unix systems: libpdf_php.* with the appropriate shared
      library suffix     

The following conditions must be met in order to use PDFlib as a
loadable module:

    - PDFlib support must not already have been compiled into your PHP version.
      If your PHP already includes PDFlib support (this is the case for
      versions of PHP distributed with many Linux distributions) you must
      rebuild PHP with the "-with-pdflib=no" configure option.
    - The PDFlib loadable module (libpdf_php.*/php_pdf.dll) must be placed in
      the directory specified in the php.ini variable "extension_dir".
    - php.ini must include the line "safe_mode=Off".
    - php.ini must include the line "enable_dl=On".
    - Several properties of your PHP version must match the loadable module
      of PDFlib. The supplied binary modules for PDFlib have been built as
      follows:
      - nondebug version
      - thread-safe
      - for a special PHP version, see "bind/php/<phpversion>

      If you get an error message similar to the following your PHP version
      number does not match that of the PDFlib module:
	    Warning:  pdf: Unable to initialize module
	    Module compiled with debug=0, thread-safety=1 module API=20001214
	    PHP compiled with debug=0, thread-safety=1 module API=20001222
      All of these options must match.
      

If you can't meet the above conditions you must choose to "Rebuild PHP" as
described below (or ask us whether your combination will be availabele soon).


Installing the module on Windows:

    - Our DLLs have been tested with the binary PHP distribution which is
      available from http://www.php4win.de

    - The PDFlib binary distribution for Windows contains several DLLs
      for different versions of PHP. Currently we offer the following
      flavors:

      - "php 4.0.4\php_pdf.dll" was built for php4.0.4 for win32[2000-12-20]
      - "php 4.0.5\php_pdf.dll" was built for php4.0.5-rc1 for win32[2001-03-16]

    - For the PHP installation please follow the documentation of your
      PHP distribution and copy "bind/php/<your phpversion>/php_pdf.dll"
      to \winnt\system32.
      

Installing the module on Unix:

    - The PDFlib binary distribution for Unix contains several shared libraries
      for different versions of PHP. Currently we offer the following
      flavors:

      - "php 4.0.4\libpdf_php.*" was built for php4.0.4pl1
      - "php 4.0.5\libpdf_php.*" was built for php4.0.5

    - Copy the file libpdf_php.* from the directory "bind/php/<phpversion>"
      of the PDFlib binary distribution to the directory which is specified in
      the "extension_dir" line in php.ini.


Using the module:

    - If you decide to load PDFlib each time PHP starts insert one line in
      php.ini:
	  extension = php_pdf.dll

    - Without the "extension = ..." line in php.ini you must include the
      following line in your PHP scripts:
      dl("libpdf_php.so");


Rebuild PHP
===========

When recompiling PHP using the library from the binary distribution of PDFlib
you have to use the library located in the "bind/c" directory of the PDFlib
distribution.

Note: Building PDFlib for PHP from the source code of PDFlib is not supported
by PDFlib GmbH since we supply precompiled binaries (although it should work,
and therefore you will find hints how to do it below).


Unix
    - Unpack the PDFlib binary distribution to <pdflib-dir>,
      or unpack the PDFlib source distribution to <pdflib-dir>, and
      issue "make; make install".
    
    - Copy the PDFlib support files for PHP to your PHP source tree:
        
      $ cp <pdflib-dir>/bind/php/ext/pdf/* <php-dir>/ext/pdf
    
    - For rebuilding PHP add the following to your PHP configure options:
	  --with-pdflib=<pdflib-dir>/bind/c
      or if building PDFlib from source:
	  --with-pdflib[=<pdflib-install-directory>]
      where <pdflib-install-directory> will typically be something like
      /usr/lib or similar.

    - Now rebuild PHP as usual, and install it.

Windows
    - Copy the PDFlib support files for PHP to your PHP source tree:
        
      C:\> copy <pdflib-dir>\bind\php\ext\pdf\*.* <php-dir>\ext\pdf
      
    - Now rebuild php_pdf.dll.


Fonts
=====

If you need special fonts or encodings you have to copy the contents of the
"fonts" directory of the PDFlib distribution to some directory on your system.

Inform PDFlib about the location of these files by one of the following
methods:

    - Set the PDFLIBRESOURCE environment variable.

    - PDF_set_parameter($p, "resourcefile", "/path/to/pdflib.upr");
      PDF_set_parameter($p, "prefix", "/path/to/fonts");

    - Use PDF_set_parameter() to set all font-specific information
      "FontAFM", "FontPFM", "FontOutline", "Encoding".
      See the PDFlib manual for details.

    - Place "pdflib.upr" whereever the current directory is while
      executing your script (not recommended). 


Samples
=======

To use the samples:

    - $ cp *.php .../htdocs #(to your htdocs directory)
    - $ cp ../../doc/PDFlib-manual-activex.pdf .../htdocs #(to your htdocs)
    - $ cp ../../doc/PDFlib-purchase-order.pdf .../htdocs #(to your htdocs)
    - $ cp ../../test/nesrin.jpg .../htdocs #(to your htdocs)
    - point your browser to the sample files
    - enjoy the generated PDFs
