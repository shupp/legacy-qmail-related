// $Id: hello.cpp,v 1.5.2.1 2001/05/16 12:25:50 york Exp $
// PDFlib client: hello example in C++
//
//

#include <stdio.h>
#include <stdlib.h>

#include "pdflib.hpp"

int
main(void)
{
    PDF *p;			// pointer to the PDF class
    int font;

    p = new PDF();

    // Open new PDF file
    if (p->open("hello.pdf") == -1) {
	fprintf(stderr, "Error: cannot open PDF file hello.pdf.\n");
	exit(2);
    }

    p->set_info("Creator", "hello.cpp");
    p->set_info("Author", "Thomas Merz");
    p->set_info("Title", "Hello, world (C++)!");

    // start a new page
    p->begin_page((float) a4_width, (float) a4_height);

    font = p->findfont("Helvetica-Bold", "host", 0);

    p->setfont(font, 24);

    p->set_text_pos(50, 700);
    p->show("Hello, world!");
    p->continue_text("(says C++)");
    p->end_page();				// finish page

    p->close();					// close PDF document
    delete p;

    return(0);
}
