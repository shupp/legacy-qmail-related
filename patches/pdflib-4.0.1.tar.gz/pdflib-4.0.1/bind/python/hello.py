#!/usr/bin/python
# $Id: hello.py,v 1.6.2.1 2001/05/16 12:25:50 york Exp $
#
# PDFlib client: hello example in Python
#

from sys import *
from pdflib_py import *

p = PDF_new()

if PDF_open_file(p, "hello.pdf") == -1:
    print "Couldn't open PDF file 'hello.pdf'\n"
    exit(2)

PDF_set_info(p, "Author", "Thomas Merz")
PDF_set_info(p, "Creator", "hello.py")
PDF_set_info(p, "Title", "Hello world (Python)")

PDF_begin_page(p, 595, 842)
font = PDF_findfont(p, "Helvetica-Bold", "host", 0)

PDF_setfont(p, font, 18.0)

PDF_set_text_pos(p, 50, 700)
PDF_show(p, "Hello world!")
PDF_continue_text(p, "(says Python)")
PDF_end_page(p)
PDF_close(p)

PDF_delete(p)
