/* 
 * QmailAdmin 
 * Copyright (C) 1999 Inter7 Internet Technologies, Inc. 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pwd.h>
#include <dirent.h>
#include "config.h"
#include "qmailadmin.h"
#include "qmailadminx.h"

show_locals()
{
 FILE *fs;
 char tmpbuf[30];

	sprintf(tmpbuf, "%s/control/locals", QMAILDIR);
	fs = fopen(tmpbuf, "r");
	if ( fs == NULL ) {
		fprintf(actout, "%s/control/locals not found\n", QMAILDIR);
		return(0);
	}

	fprintf(actout,"Locals<BR>\n");
	fprintf(actout,"<TABLE>\n");
	while( fgets(TmpBuf, MAX_BUFF, fs) != NULL ) {
		fprintf(actout,"<TR><TD align=center>%s</TD></TR>\n", TmpBuf);
	}
	fprintf(actout,"</TABLE>\n");
	fclose(fs);
}
show_rcpthosts()
{
 FILE *fs;
 char tmpbuf[30];

	sprintf(tmpbuf, "%s/control/rcpthosts", QMAILDIR);

	fs = fopen(tmpbuf, "r");
	if ( fs == NULL ) {
		fprintf(actout, "%s/control/rcpthosts not found\n", QMAILDIR);
		return(0);
	}

	fprintf(actout,"Rcpthosts<BR>\n");
	fprintf(actout,"<TABLE>\n");
	while( fgets(TmpBuf, MAX_BUFF, fs) != NULL ) {
		fprintf(actout,"<TR><TD align=center>%s</TD></TR>\n", TmpBuf);
	}
	fprintf(actout,"</TABLE>\n");
	fclose(fs);
}
show_virtualdomains()
{
 FILE *fs;
 char tmpbuf[30];

	sprintf(tmpbuf, "%s/control/virtualdomains", QMAILDIR);

	fs = fopen(tmpbuf, "r");
	if ( fs == NULL ) {
		fprintf(actout, "%s/control/virtualdomains not found\n", QMAILDIR);
		return(0);
	}

	fprintf(actout,"virtualdomains<BR>\n");
	fprintf(actout,"<TABLE>\n");
	while( fgets(TmpBuf, MAX_BUFF, fs) != NULL ) {
		fprintf(actout,"<TR><TD align=center>%s</TD></TR>\n", TmpBuf);
	}
	fprintf(actout,"</TABLE>\n");
	fclose(fs);
}

show_assign()
{
 FILE *fs;
 char tmpbuf[30];

	sprintf(tmpbuf, "%s/control/assign", QMAILDIR);

	fs = fopen(tmpbuf, "r");
	if ( fs == NULL ) {
		fprintf(actout, "%s not found\n", tmpbuf);
		return(0);
	}

	fprintf(actout,"assign<BR>\n");
	fprintf(actout,"<TABLE>\n");
	while( fgets(TmpBuf, MAX_BUFF, fs) != NULL ) {
		fprintf(actout,"<TR><TD align=center>%s</TD></TR>\n", TmpBuf);
	}
	fprintf(actout,"</TABLE>\n");
	fclose(fs);
}

show_menu(user, dom, mytime)
 char *user;
 char *dom;
 time_t mytime;
{
		send_template( "main_menu.html" );
}

show_login()
{
	send_template( "show_login.html" );
}
