./configure \
 --enable-mysql=y \
 --enable-file-sync=n \
 --enable-auth-logging=y \
 --enable-valias=y \
 --enable-mysql-limits=y \
