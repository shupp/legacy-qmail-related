/* QmailAdmin 
 * Copyright (C) 1999 Inter7 Internet Technologies, Inc. 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pwd.h>
#include <dirent.h>
#include <errno.h>
#include "config.h"
#include "qmailadmin.h"
#include "qmailadminx.h"
#include "vpopmail.h"
#include "vpopmail_config.h"
#include "vauth.h"


#define HOOKS 1

#ifdef DEBUG
#include <syslog.h>
#endif

#ifdef HOOKS
#define HOOK_ADDUSER 0
#define HOOK_DELUSER 1
#define HOOK_MODUSER 2
#define HOOK_ADDMAILLIST 3
#define HOOK_DELMAILLIST 4
#define HOOK_MODMAILLIST 5
#define HOOK_LISTADDUSER 6
#define HOOK_LISTDELUSER 7
#endif


show_users()
{
        if (MaxPopAccounts == 0) {
                return (0);
        }
        send_template("show_users.html");
}


show_user_lines(user,dom,mytime,dir)
 char *user;
 char *dom;
 time_t mytime;
 char *dir;
{
 int  i,j,k,startnumber,moreusers = 1;
 FILE *fs;
 struct vqpasswd *pw;
 char spaces[MAX_BUFF];
 int totalpages;
 int bounced;

 	if ( MaxPopAccounts == 0 ) {
		return(0);
	}

	/* Get the default catchall box name */
	if ( (fs=fopen(".qmail-default","r"))==NULL) {
		fprintf(actout,"%s %s<br>\n", get_html_text("144"), ".qmail-default");
		vclose();
		exit(0);
	}
	fgets( TmpBuf, MAX_BUFF, fs);
	fclose(fs);

	if (*SearchUser) {
		pw = vauth_getall(dom,1,1);
		for (k=0; pw!=NULL; k++) {
			if ((!SearchUser[1] && *pw->pw_name >= *SearchUser) ||
			   ((!strcmp(SearchUser, pw->pw_name)))) {
				break;
			}

			pw = vauth_getall(dom,0,0);
		}

		if (k == 0) {
			sprintf(Pagenumber, "1");
		} else {
			sprintf(Pagenumber, "%d", (k/MAXUSERSPERPAGE)+1);
		}
	}

	/* Determine number of pages */
    pw = vauth_getall(dom,1,1);
    for (k=0; pw!=NULL; k++) {
        pw = vauth_getall(dom,0,0);
    }

    if (k == 0) {
        totalpages = 1;
    } else {
        totalpages = ((k/MAXUSERSPERPAGE)+1);
    }
	/* End determine number of pages */


	if (atoi(Pagenumber)==0) {
		*Pagenumber='1';
	}

	if ( strstr(TmpBuf, "bounce-no-mailbox") != NULL ) {
		bounced = 1;
	} else if ( strstr(TmpBuf, "@") != NULL ) {
		bounced = 0;
	} else {
		bounced = 0;
		i = strlen(TmpBuf); --i; TmpBuf[i] = 0; /* take off newline */
		for(;TmpBuf[i]!='/';--i);
		for(j=0,++i;TmpBuf[i]!=0;++j,++i) TmpBuf3[j] = TmpBuf[i];
		TmpBuf3[j]=0;
	}
	

	startnumber = MAXUSERSPERPAGE * (atoi(Pagenumber) - 1);
	/* check to see if there are any users to list, 
	 * otherwise repeat previous page 
	 */
	pw = vauth_getall(dom,1,1);
	if ( AdminType==SYSTEM_ADMIN || AdminType==DOMAIN_ADMIN ||
		(AdminType==USER_ADMIN && strcmp(pw->pw_name,Username)==0)){

		for (k = 0; k < startnumber; ++k) { 
			pw = vauth_getall(dom,0,0); 
		}
	}

    /* make the html pretty ; ) */
    strcpy(spaces, "\t\t\t\t\t\t\t\t\t\t\t");

	if (pw == NULL) {
		fprintf(actout,"\n");
		fprintf(actout,"%s<TR>\n", spaces);
		fprintf(actout,"%s\t<TD colspan=5 bgcolor=%s>%s</TD>\n",
			spaces, get_color_text("000"), get_html_text("131"));
		fprintf(actout,"%s</TR>\n", spaces);
		fprintf(actout,"%s<TR>\n", spaces);
		fprintf(actout,"%s\t<TD colspan=5 bgcolor=%s><CENTER>", spaces, get_color_text("002"));
		moreusers = 0;
	} else {

		while( ( pw != NULL ) && ((k < MAXUSERSPERPAGE + startnumber) ||  
		        ( AdminType!=DOMAIN_ADMIN || AdminType!=DOMAIN_ADMIN || 
				(AdminType==USER_ADMIN && strcmp(pw->pw_name,Username)==0)))) {
			if ( AdminType==SYSTEM_ADMIN || AdminType==DOMAIN_ADMIN || 
				(AdminType==USER_ADMIN && strcmp(pw->pw_name,Username)==0)){

				fprintf(actout,"%s<TR>\n%s    <TD bgcolor=%s>%s</TD>\n",
					spaces, spaces, get_color_text("000"), pw->pw_name);
				fprintf(actout,"%s    <TD bgcolor=%s>%s</TD>\n", 
					spaces, get_color_text("000"), pw->pw_gecos);
         		fprintf(actout, "%s    <TD align=center bgcolor=%s><A href=%s/com/moduser?user=%s&dom=%s&time=%d&moduser=%s>\
<img src=\"/images/qmailadmin/delete.gif\" border=0></A></TD>\n",
					spaces, get_color_text("000"), CGIPATH, user,dom,mytime,pw->pw_name);
			
				if ( strncmp( pw->pw_name, "postmaster", 11) == 0 ) {
					fprintf(actout, "%s    <TD align=center bgcolor=%s>-</td>", spaces, get_color_text("000"));
				} else if (AdminType==DOMAIN_ADMIN){
					fprintf(actout, "%s    <TD align=center bgcolor=%s><a href=%s/com/deluser?user=%s&dom=%s&time=%d&deluser=%s>\
<img src=\"/images/qmailadmin/delete.gif\" border=0></a></td>\n",
						spaces, get_color_text("000"), CGIPATH, user,dom,mytime,pw->pw_name);
				} else {
					fprintf(actout, "%s    <TD align=center bgcolor=%s>-</td>\n", spaces, get_color_text("000"));
				}

				if ( bounced==0 && strncmp(pw->pw_name,TmpBuf3,MAX_BUFF)==0 ) {
					fprintf(actout,"%s    <TD align=center bgcolor=%s>%s</td>\n",
						spaces, get_color_text("000"), get_html_text("132"));
				} else if (AdminType==DOMAIN_ADMIN) {
					fprintf(actout,"%s    <TD align=center bgcolor=%s><a href=%s/com/setdefault?user=%s&dom=%s&time=%d&deluser=%s&page=%s>\
<img src=\"/images/qmailadmin/delete.gif\" border=0></a></td>\n",
						spaces, get_color_text("000"), CGIPATH, user,dom,mytime,pw->pw_name,Pagenumber);
				} else {
					fprintf(actout, "%s    <TD align=center bgcolor=%s>-</td>\n", spaces, get_color_text("000"));
				}

				fprintf(actout,"%s</TR>\n", spaces);
			}		
			pw = vauth_getall(dom,0,0);
			++k;
		}

		fprintf(actout,"%s<TR>\n%s    <TD colspan=5 bgcolor=%s><CENTER>\n", spaces, spaces, get_color_text("002"));
	}

		if ( AdminType==DOMAIN_ADMIN ) {

			fprintf(actout, "%s    <br>\n", spaces);
			fprintf(actout, "%s    <table border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\n", spaces);
			fprintf(actout, "%s        <tr valign=\"middle\">\n", spaces);
			fprintf(actout, "%s            <td valign=\"middle\" align=\"right\"><b>%s</b>&nbsp;</td>\n", spaces, get_html_text("133"));
			fprintf(actout, "%s            <td align=\"middle\">\n", spaces);

			for (k = 97; k < 123; k++) {
				fprintf(actout, "%s            <A href=%s/com/showusers?user=%s&dom=%s&time=%d&searchuser=%c>%c</A> \n",
					spaces, CGIPATH, user, dom, mytime, k, k);
			}

			fprintf(actout, "%s            <br>\n", spaces);

			for (k = 0; k < 10; k++) {
				fprintf(actout, "%s            <A href=%s/com/showusers?user=%s&dom=%s&time=%d&searchuser=%d>%d</A>\n",
					spaces, CGIPATH, user, dom, mytime, k, k);
			}

			fprintf(actout, "%s            </td>\n", spaces);
			fprintf(actout, "%s        </tr>\n", spaces);
			fprintf(actout, "%s    </table", spaces);

			fprintf(actout, "%s    <br>\n", spaces);
			fprintf(actout, "%s    <form method=get action=%s/com/showusers>\n",
				spaces, CGIPATH);
			fprintf(actout, 
				"%s    <input type=hidden name=user value=%s>\n", spaces, user);
			fprintf(actout, 
				"%s    <input type=hidden name=dom value=%s>\n", spaces, dom);
			fprintf(actout, 
				"%s    <input type=hidden name=time value=%d>\n", spaces, mytime);
			fprintf(actout, 
				"%s    <input type=text name=searchuser value=\"%s\">\n", spaces, SearchUser);
			fprintf(actout, "%s    <input type=submit value=\"%s\">\n",
				spaces, get_html_text("204"));
			fprintf(actout, 
				"%s    </form>\n", spaces);

			/* only display "previous page" if pagenumber > 1 */
			if(atoi(Pagenumber) > 1) {
				fprintf(actout,
				"%s    <A href=%s/com/showusers?user=%s&dom=%s&time=%d&page=%d>%s</a>&nbsp;&nbsp;\n",
               		spaces, CGIPATH, user, dom, mytime,
					atoi(Pagenumber)-1 ? atoi(Pagenumber)-1 : atoi(Pagenumber), 
					get_html_text("135"));
			}
               	
			fprintf(actout,"%s    <a href=%s/com/showusers?user=%s&dom=%s&time=%d&page=%s>%s</a>&nbsp;&nbsp;",
                spaces, CGIPATH, user,dom,mytime,Pagenumber, get_html_text("136"));

			if (moreusers && atoi(Pagenumber) < totalpages) {

				fprintf(actout,"%s    <A href=%s/com/showusers?user=%s&dom=%s&time=%d&page=%d>%s</A>\n",
					spaces, CGIPATH, user, dom,mytime,atoi(Pagenumber)+1,
					get_html_text("137"));
			}

			fprintf(actout,"%s    <P><CENTER><A href=%s/com/bounceall?user=%s&dom=%s&time=%d>%s</A>&nbsp;&nbsp;\n", 
				spaces, CGIPATH, user, dom,mytime, get_html_text("134"));
			fprintf(actout,"%s    <A href=%s/com/setremotecatchall?user=%s&dom=%s&time=%d>%s</A></CENTER><BR>\n", 
				spaces, CGIPATH, user, dom,mytime, get_html_text("206"));
		}
		fprintf(actout,"%s    </TD></TR>\n", spaces);
		fprintf(actout,"%s</TR>\n", spaces);

}

adduser()
{
	count_users();
	load_limits();

	if ( AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}
                                                
	if ( MaxPopAccounts != -1 && CurPopAccounts >= MaxPopAccounts ) {
		sprintf(StatusMessage, "%s %d\n", get_html_text("199"),
			MaxPopAccounts);
		show_menu();
		vclose();
		exit(0);
	}

	send_template( "add_user.html" );

}

moduser()
{
	if (!( AdminType==SYSTEM_ADMIN || AdminType==DOMAIN_ADMIN ||
		  (AdminType==USER_ADMIN && strcmp(ActionUser,Username)==0))){
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}
	send_template( "mod_user.html" );
} 

addusernow()
{
 char pw[50];
 int cnt=0, num;
 char c_num[MAX_BUFF];
 char **mailingListNames;
 char tmp[MAX_BUFF];
 char email[128];
 char *arguments[MAX_BUFF];
 int pid;
 int i;
 int error;

        count_users();
        load_limits();

	if ( AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

        if ( MaxPopAccounts != -1 && CurPopAccounts >= MaxPopAccounts ) {
                sprintf(StatusMessage, "%s %d\n", get_html_text("199"),
                        MaxPopAccounts);
                show_menu();
                vclose();
                exit(0);
        }
 
	GetValue(TmpCGI,Newu, "newu=", MAX_BUFF);

	if ( fixup_local_name(Newu) ) {
		sprintf(StatusMessage, "%s %s\n", get_html_text("148"), Newu);
		adduser();
		vclose();
		exit(0);
	} 

	if ( check_local_user(Newu) ) {
		sprintf(StatusMessage, "%s %s\n", get_html_text("175"), Newu);
		adduser();
		vclose();
		exit(0);
	} 
	GetValue(TmpCGI,Password1, "password1=", MAX_BUFF);
	GetValue(TmpCGI,Password2, "password2=", MAX_BUFF);
	if ( strncmp( Password1, Password2, MAX_BUFF ) != 0 ) {
		sprintf(StatusMessage, "%s\n", get_html_text("200"));
		vclose();
		exit(0);
	}

	strcpy(email, "");
	strcat(email,Newu);
	strcat(email,"@");
	strcat(email,Domain);
	
	GetValue(TmpCGI,Gecos, "gecos=", MAX_BUFF);
	if ( strlen( Gecos ) == 0 ) {
		strcpy(Gecos, Newu);
	}

	GetValue(TmpCGI, c_num, "number_of_mailinglist=", MAX_BUFF);
	num = atoi(c_num);
	if(!(mailingListNames = malloc(sizeof(char *) * num))) {
		sprintf(StatusMessage, "%s\n", get_html_text("201"));
		vclose();
	   exit(0);

	} else {

		for(cnt = 0; cnt < num; cnt++) {

			if(!(mailingListNames[cnt] = malloc(MAX_BUFF))) {
				sprintf(StatusMessage, "%s\n", get_html_text("201"));
		vclose();
				exit(0);
			}
		}

		for(cnt = 0; cnt < num; cnt++) {
			sprintf(tmp, "subscribe%d=", cnt);
			error = GetValue(TmpCGI, mailingListNames[cnt], tmp, MAX_BUFF);
			if( error != -1 ) {
				pid=fork();
				if (pid==0) {
					sprintf(TmpBuf1, "%s/ezmlm-sub", EZMLMDIR);
					sprintf(TmpBuf2, "%s/%s", RealDir, mailingListNames[cnt]);
					execl(TmpBuf1, "ezmlm-sub", TmpBuf2, email, NULL);
					exit(127);
				} else wait(&pid);
			} 
		}
	}

	if ( vadduser( Newu, Domain, Password1, Gecos, USE_POP ) == 0 ) {

		/* set domain's user defaults via vmoduser */
		load_user_defaults();
		if (CallVmoduser > 0) {
			pid=fork();
			if (pid==0) {
				sprintf(TmpBuf1, "%s/bin/vmoduser", VPOPMAILDIR);
				sprintf(TmpBuf2, "%s@%s", Newu, Domain);
				strcpy(TmpBuf3, "-");

				if(DisablePOP > 0) {
					strcat(TmpBuf3, "p");
				}
				if(DisableIMAP > 0) {
					strcat(TmpBuf3, "i");
				}
				if(DisableDialup > 0) {
					strcat(TmpBuf3, "u");
				}
				if(DisablePasswordChanging > 0) {
					strcat(TmpBuf3, "d");
				}
				if(DisableWebmail > 0) {
					strcat(TmpBuf3, "w");
				}
				if(DisableRelay > 0) {
					strcat(TmpBuf3, "r");
				}

				execl(TmpBuf1, "vmoduser", TmpBuf3, TmpBuf2, NULL);
				exit(127);
			} else wait(&pid);
	    	}


		sprintf(StatusMessage, "%s %s@%s (%s) %s",
			get_html_text("002"),
			Newu, Domain, Gecos,
			get_html_text("119"));

	} else {
		sprintf(StatusMessage, "<font color=\"red\">%s %s@%s (%s) %s</font>", 
			get_html_text("002"),
			Newu, Domain, Gecos,
			get_html_text("120"));
	}

	call_hooks( HOOK_ADDUSER );
	show_menu(Username, Domain, Mytime);
}

int call_hooks( int hook_type )
{
    FILE *fs = NULL;
	int pid;
    char hooks_path[MAX_BUFF];
    char *cmd;
    char *tmpstr;
    int len = 0;
    int error;
	char *hooks[15] = {"adduser",
					   "deluser",
					   "moduser",
					   "addmaillist",
					   "delmaillist",
					   "modmaillist",
					   "listadduser",
					   "listdeluser"};
	

	sprintf(hooks_path, "%s/.qmailadmin-hooks", RealDir, Domain);
	if((fs = fopen(hooks_path, "r")) == NULL) {
		sprintf(hooks_path, "%s/.qmailadmin-hooks", RealDir);
		if((fs = fopen(hooks_path, "r")) == NULL) {
			return (0);
		}
	}

	while(fgets(TmpBuf, MAX_BUFF, fs) != NULL)
	{
		tmpstr = strtok(TmpBuf, " :\t\n");
		if ( (tmpstr[0] == '#') || (tmpstr == NULL)) continue;

		if ( strncmp(tmpstr, hooks[hook_type], strlen(hooks[hook_type])) == 0)
		{
			tmpstr = strtok(NULL, " :\t\n");

			if ( tmpstr == NULL)
				continue;
		
			len = strlen(tmpstr);
			if (!(cmd = malloc(len + 1)))
				return (0);
			else
			{
				sprintf(cmd, "%s", tmpstr);
				strcat(cmd, "");
			}

			break;
		}
	}

	fclose(fs);
	
#ifdef DEBUG
    fprintf(actout, "Where the parameters are: %s, \"%s\", %s, %s, %s, %s, NULL);", cmd, hooks[hook_type], Newu, Domain, Password1, Gecos);
#endif
	
	pid = fork();

#ifdef DEBUG
    fprintf(actout, "Where the parameters are: %s, \"%s\", %s, %s, %s, %s, NULL);", cmd, hooks[hook_type], Newu, Domain, Password1, Gecos);
#endif 

	if (pid == 0) {
		error =	execl(cmd, Newu, Domain, Password1, Gecos, NULL);
    	sprintf(StatusMessage, "%s, \"%s\", %s, %s, %s, %s\n",
			get_html_text("202"), cmd, hooks[hook_type], 
			Newu, Domain, Password1, Gecos);
		if (error == -1) 
			return (-1);
		exit(127);
	}else
		wait(&pid);

	return (0);
}

deluser()
{
	send_template( "del_user_confirm.html" );

}

delusergo()
{
	char forward[200];
	char forwardto[200];
 	FILE *fs;
	int i;
	struct vqpasswd *pw;
	 
	if ( AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	vdeluser( ActionUser, Domain );

	/* Start create forward when delete - 
	 * Code added by Eugene Teo 6 June 2000 */

	GetValue(TmpCGI,forward, "forward=", MAX_BUFF);

#ifdef DEBUG
	fprintf(actout, "Forward: %s\n<br>", forward);
#endif

	if (strcmp(forward, "on") == 0)
	{
		/* replace "." in name with ":" */	

		sprintf(TmpBuf2, ".qmail-%s", ActionUser);
		for(i=6;TmpBuf2[i]!=0;++i) if ( TmpBuf2[i] == '.' ) TmpBuf2[i] = ':';
	
	        if ((fs=fopen(TmpBuf2,"w")) == NULL) 
			ack("Failed to open passwd file",21);
	
		GetValue(TmpCGI, forwardto, "forwardto=", MAX_BUFF);
		
#ifdef DEBUG		
		fprintf(actout, "Forward to: %s\n<br>", forwardto);
#endif

		fprintf(fs, "&%s", forwardto);
		fclose(fs);
		
		/* End create forward when delete - 
		 * Code added by Eugene Teo 6 June 2000 
		 */
	}
	
	sprintf(StatusMessage, "%s %s", 
		ActionUser, 
		get_html_text("141"));
	
	call_hooks(HOOK_DELUSER);
	show_users(Username, Domain, Mytime);

}

count_users()
{
 struct vqpasswd *pw;

	CurPopAccounts = 0;
	pw = vauth_getall(Domain,1,0);
     while(pw!=NULL){
		++CurPopAccounts;
		pw = vauth_getall(Domain,0,0);
	}
}

setremotecatchall() {
	send_template("setremotecatchall.html");
}

setremotecatchallnow() 
{
	GetValue(TmpCGI,Newu, "newu=", MAX_BUFF);

	if (check_email_addr(Newu) ) {
        	sprintf(StatusMessage, "%s %s\n", get_html_text("148"), Newu);
		setremotecatchall();
		exit(0);
	}
	set_remote_catchall_now();
}

set_remote_catchall_now()
{
 FILE *fs;

        if ( (fs = fopen(".qmail-default", "w")) == NULL ) {
                fprintf(actout,"%s %s<br>\n", get_html_text("144"), ".qmail-default");
        } else {
                fprintf(fs,"| %s/bin/vdelivermail '' %s\n",VPOPMAILDIR,Newu);
                fclose(fs);
        }
        show_users(Username, Domain, Mytime);
        exit(0);
}

void bounceall()
{
 FILE *fs;

	if ( (fs = fopen(".qmail-default", "w")) == NULL ) {
		fprintf(actout,"%s %s<br>\n", get_html_text("144"), ".qmail-default");
	} else {
		fprintf(fs,"| %s/bin/vdelivermail '' bounce-no-mailbox\n",VPOPMAILDIR);
		fclose(fs);
	}
	show_users(Username, Domain, Mytime);
		vclose();
	exit(0);
}

get_catchall()
{
 int  i,j;
 FILE *fs;

        /* Get the default catchall box name */
        if ( (fs=fopen(".qmail-default","r"))==NULL) {
                fprintf(actout,"%s %s<br>\n", get_html_text("144"), ".qmail-default");
                vclose();
                exit(0);
        }
        fgets( TmpBuf, MAX_BUFF, fs);
        fclose(fs);

        if ( strstr(TmpBuf, "bounce-no-mailbox") != NULL ) {
                fprintf(actout,"<b>%s</b>", get_html_text("130"));
        } else if ( strstr(TmpBuf, "@") != NULL ) {
                i=strlen(TmpBuf);
                for(;TmpBuf[i]!=' ';--i);
                fprintf(actout,"<b>%s %s</b>", get_html_text("062"),&TmpBuf[i]);
        } else {
                i = strlen(TmpBuf) - 1;
                for(;TmpBuf[i]!='/';--i);
                for(++i,j=0;TmpBuf[j]!=0;++j,++i) TmpBuf2[j] = TmpBuf[i];
                TmpBuf2[j--] = '\0';
				i = strlen(TmpBuf2); --i; TmpBuf2[i] = 0; /* take off newline */
                fprintf(actout,"<b>%s %s</b>", get_html_text("062"), TmpBuf2);
        }
}

modusergo()
{
 char crypted[20]; 
 char *tmpstr;
 int i;
 int ret_code;
 int password_updated = 0;
 struct vqpasswd *vpw=NULL;
 char box[50];
 char NewBuf[156];
 int count;
 FILE *fs;

    if (!( AdminType==DOMAIN_ADMIN ||
         (AdminType==USER_ADMIN && strcmp(ActionUser,Username)==0))){
        sprintf(StatusMessage,"<h2>%s</h2>", get_html_text("142"));
        vclose();
        exit(0);
    }

    if (strlen(Password1)>0 && strlen(Password2)>0 ) {
        if ( strncmp( Password1, Password2, MAX_BUFF ) != 0 ) {
        	sprintf(StatusMessage, "<h2>%s</h2>\n", get_html_text("200"));
        	moduser();
        	vclose();
        	exit(0);
        }
        ret_code = vpasswd( ActionUser, Domain, Password1, USE_POP);
        if ( ret_code != VA_SUCCESS ) {
            sprintf(StatusMessage, "<h2>%s</h2>", get_html_text("140"));
        } else {
            sprintf(StatusMessage,"<h2>%s %s %s %s %s</h2>", 
                get_html_text("139"), ActionUser, Domain, Password1, 
                verror(ret_code) );
        }
    }

    GetValue(TmpCGI,Gecos, "gecos=", MAX_BUFF);
    if ( strlen( Gecos ) != 0 ) {
        vpw = vauth_getpw(ActionUser, Domain); 
        vpw->pw_gecos = Gecos;
        vauth_setpw(vpw, Domain);
    }


    /* get the value of the cforward radio button */
    GetValue(TmpCGI,box, "cforward=", MAX_BUFF);

    /* if they want to disable everything */
    if ( strcmp(box,"disable") == 0 ) {

        /* unlink the .qmail file */
        if ( vpw == NULL ) vpw = vauth_getpw(ActionUser, Domain); 
        snprintf(NewBuf,156,"%s/.qmail", vpw->pw_dir);
        unlink(NewBuf);

        /* delete any vacation directory */
        snprintf(NewBuf,156,"%s/vacation", vpw->pw_dir);
        vdelfiles(NewBuf);

    /* if they want to forward */
    } else if (strcmp(box,"forward") == 0 ) {

        /* get the value of the foward */
        GetValue(TmpCGI,box, "nforward=", MAX_BUFF);

        /* If nothing was entered, error */
        if ( box[0] == 0 ) {
            sprintf(StatusMessage, "<h2>%s</h2>\n", get_html_text("215"));
            moduser();
        	vclose();
        	exit(0);

        /* check it for a valid email address
        } else if ( check_email_addr( box ) == 1 )  {
            sprintf(StatusMessage, "<h2>%s</h2>\n", get_html_text("148"));
            moduser();
        */
        }

        /* everything looks good, open the file */
        if ( vpw == NULL ) vpw = vauth_getpw(ActionUser, Domain); 
        snprintf(NewBuf,156,"%s/.qmail", vpw->pw_dir);

        fs = fopen(NewBuf,"w+");

	tmpstr = strtok(box," ,;");
        count=0;
	while( tmpstr != NULL && count < 2) {
            fprintf(fs,"&%s\n", tmpstr);
	    tmpstr = strtok(NULL," ,");
            ++count;
        }

        /* if they want to save a copy */
        GetValue(TmpCGI,box, "fsaved=", MAX_BUFF);
        if ( strcmp(box,"on") == 0 ) {
            fprintf(fs,"%s/Maildir/\n", vpw->pw_dir);
        } 
        fclose(fs);

    /* they want vacation */
    } else if (strcmp(box,"vacation") == 0 ) {

        /* get the subject */
        GetValue(TmpCGI,box, "vsubject=", MAX_BUFF);

        /* if no subject, error */
        if ( box[0] == 0 ) {
            sprintf(StatusMessage, "<h2>%s</h2>\n", get_html_text("216"));
            moduser();
        }
 
        /* make the vacation directory */
        if ( vpw == NULL ) vpw = vauth_getpw(ActionUser, Domain); 
        snprintf(NewBuf,156,"%s/vacation", vpw->pw_dir);
        mkdir(NewBuf, 448);

        /* open the .qmail file */
        snprintf(NewBuf,156,"%s/.qmail", vpw->pw_dir);
        fs = fopen(NewBuf,"w+");
        fprintf(fs,
            "| %s/autorespond 86400 3 %s/vacation/message %s/vacation\n",
            AUTORESPOND_BIN, vpw->pw_dir, vpw->pw_dir );

        /* save a copy for the user */
        fprintf(fs,"%s/Maildir/\n", vpw->pw_dir);
        fclose(fs);

        /* set up the message file */
        snprintf(NewBuf,156,"%s/vacation/message", vpw->pw_dir);
        GetValue(TmpCGI,Message, "vmessage=",MAX_BIG_BUFF);

        if ( (fs = fopen(NewBuf, "w")) == NULL ) ack("123", 123);
        fprintf(fs, "From: %s@%s\n", ActionUser,Domain);
        fprintf(fs, "Subject: %s\n\n", box);
        fprintf(fs, "%s", Message);
        fclose(fs);
    } else {
        printf("nothing\n");
    }

    call_hooks(HOOK_MODUSER);
    moduser();
}
