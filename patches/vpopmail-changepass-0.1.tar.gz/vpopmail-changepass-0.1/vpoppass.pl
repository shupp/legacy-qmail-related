#!/usr/bin/perl -w
#
# edit the path to vpasswd if it's not correct below

@args = ("/home/vpopmail/bin/vpasswd", $ARGV[0], $ARGV[1]);

system @args;
