#!/bin/sh
#
# Install script for vchangepass
# By Bill Shupp hostmaster@shupp.org


PATH='$PATH:/bin:/usr/bin:/usr/local/bin'
export PATH

CWD=`pwd`
PATCH="$CWD/imp.patch"

# Get the IMP directory
echo "Please enter the path to your IMP directory:"
read IMPDIR

# Make sure that directory exists
if [ ! -d "$IMPDIR" ] ; then
  echo "Error: \"$IMPDIR\" doesn't appear to exist"
  exit
fi

# Make sure the files to be patched exist
if [ ! -f "$IMPDIR/poppassd.php3" ] ; then
  echo "Error: \"$IMPDIR/poppassd.php3\" doesn't appear to exist"
  exit
fi
if [ ! -f "$IMPDIR/templates/menu/menu.inc" ] ; then
  echo "Error: \"$IMPDIR/templates/menu/menu.inc\" doesn't appear to exist"
  exit
fi


echo -e "\nLooks good!\n\n";


# Get the vchangepass info
echo -e "Now, please enter the FULL path to the directory where
vchangepass program will be installed:"

read VCHANGEPASSDIR

# Make sure that directory exists
if [ ! -d "$VCHANGEPASSDIR" ] ; then
  echo "Error: \"$VCHANGEPASSDIR\" doesn't appear to exist"
  exit
fi

echo -e "\nLooks good too!\n\n";

# Get the vpopmaildir info
echo -e "Lastly, please enter the FULL path to the vpopmail home directory:"
read VPOPMAILDIR

# Make sure that directory exists
if [ ! -d "$VPOPMAILDIR" ] ; then
  echo "Error: \"$VPOPMAILDIR\" doesn't appear to exist"
  exit
fi

# Make sure the patch will work
cat $PATCH | sed "s!@VCHANGEPASS@!$VCHANGEPASSDIR/vchangepass!g" | sed -e "s!@VPOPMAILDIR@!$VPOPMAILDIR!g" > $PATCH.temp

PATCHTEST=`(cd $IMPDIR ; cat $PATCH.temp | patch -p0 --dry-run -s)`

if [ ! -z "$PATCHTEST" ] ; then
  echo "Error: patch test failed: $PATCHTEST"
  rm $PATCH.temp
  exit
fi

echo -e "\nAlright, now we'll install the stuff:\n";

echo -n "Installing vchangepass ... "
cp $CWD/vchangepass $VCHANGEPASSDIR
chown vpopmail.vchkpw $VCHANGEPASSDIR/vchangepass
chmod 755 $VCHANGEPASSDIR/vchangepass
chmod ug+s $VCHANGEPASSDIR/vchangepass
echo "done."

echo -n "Installing IMP patch   ... "
(cd $IMPDIR ; cat $PATCH.temp | patch -p0 -s)
echo "done."
rm $PATCH.temp >/dev/null 2>&1

echo -e "\n\nOk, you should be good to go.  Just don't forget to change:\n \
$default->change_password = false;\n \
to:\n \
$default->change_password = true;\n \
\n \
in $IMPDIR/config/defaults.php3\n"
