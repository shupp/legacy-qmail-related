#include <stdlib.h>
#include <stdio.h>
#include <string.h>


int main(int argc, char ** argv) {
 char pathtovpasswd[100];
	if(argc<4) {
		/* make sure there are three arguments to this program */
		fprintf(stderr, "Usage: %s <path to vpopmail homedir> <address> <password>\n",argv[0]);
		exit(-1);
	} else {

		/* format the path to vpasswd */
		strcpy(pathtovpasswd, argv[1]);
		strcat(pathtovpasswd, "/bin/vpasswd");

		/* run it */
		execl(pathtovpasswd, "vpasswd", argv[2], argv[3], NULL);	
	}
}
