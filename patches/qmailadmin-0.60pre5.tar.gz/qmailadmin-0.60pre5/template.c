/* 
 * QmailAdmin 
 * Copyright (C) 1999 Inter7 Internet Technologies, Inc. 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pwd.h>
#include <dirent.h>
#include <vpopmail.h>
#include <vauth.h>
#include "config.h"
#include "qmailadmin.h"
#include "qmailadminx.h"

static char dchar[4];
void check_user_forward_vacation(char newchar);

static char NTmpBuf[156];

/*
 * send an html template to the browser 
 *
 */
send_template( filename )
 char *filename;
{
 FILE *fs;
 int   i;
 int   j;
 int   inchar;
 char *tmpstr;

    tmpstr = getenv(QMAILADMIN_TEMPLATEDIR);
    if (tmpstr == NULL ) tmpstr = HTMLLIBDIR;

    sprintf( TmpBuf2, "%s/%s", tmpstr, filename);

    /* open the template */
    fs = fopen( TmpBuf2, "r" );
    if ( fs == NULL ) {
        fprintf(actout,"%s %s<br>\n", get_html_text("144"), TmpBuf2);
        return(0);
    }

    /* parse the template looking for "##" pattern */
    while( (inchar = fgetc(fs)) >= 0 ) {

        /* if not '#' then send it */
        if ( inchar != '#' ) {
            fputc(inchar, actout);

        /* found a '#' */
        } else {

            /* look for a second '#' */
            inchar = fgetc(fs);
            if ( inchar < 0 ) {
                break;

            /* found a tag */
            } else if ( inchar == '#' ) {
                inchar = fgetc(fs);
                if ( inchar < 0 ) break;

                /* switch on the tag */
                switch( inchar ) {

                    /* dictionary line, we three more chars for the line */
                    case 'X':
                        for(i=0;i<3;++i) dchar[i] = fgetc(fs);
                        dchar[i] = 0;
                        printf("%s", get_html_text( dchar ));
                        break;

                    case 'p':
                        show_user_lines(Username, Domain, Mytime, RealDir);
                        break;

                    case 'v':
                        fprintf(actout,"<BR><FONT SIZE=2 COLOR=red><B>%s</B><BR>",
                            get_html_text("001"));
                        if (AdminType==SYSTEM_ADMIN || AdminType==DOMAIN_ADMIN){
                            if (MaxPopAccounts !=0 ) {
                                fprintf(actout, "<A href=%s/com/showusers?user=%s&time=%i&dom=%s&>\
<FONT SIZE=2 COLOR=BLACK><B>%s</B></a><BR>\n",
                                    CGIPATH, Username,Mytime,Domain, 
                                    get_html_text("061"));
                            }

                            if (MaxAliases !=0 ) {
                                fprintf(actout,"<A href=%s/com/showaliases?user=%s&time=%i&dom=%s&>\
<FONT SIZE=2 COLOR=BLACK><B>%s</B></a><BR>\n",
                                    CGIPATH, Username,Mytime,Domain, 
                                    get_html_text("121"));
                            }
                            if (MaxForwards !=0 ) {
                                fprintf(actout,"<A href=%s/com/showforwards?user=%s&time=%i&dom=%s&>\
<FONT SIZE=2 COLOR=BLACK><B>%s</B></a><BR>\n",
                                    CGIPATH, Username,Mytime,Domain,
                                    get_html_text("122"));
                            }
                            if (MaxAutoResponders !=0 ) {
                                fprintf(actout,"<A href=%s/com/showautoresponders?user=%s&time=%i&dom=%s&>\
<FONT SIZE=2 COLOR=BLACK><B>%s</B></a><BR>\n",
                                    CGIPATH, Username,Mytime,Domain,
                                    get_html_text("077"));
                            }
                            if (MaxMailingLists !=0 ) {
                                fprintf(actout,"<A href=%s/com/showmailinglists?user=%s&time=%i&dom=%s&>\
<FONT SIZE=2 COLOR=BLACK><B>%s</B></a><BR>\n",
                                    CGIPATH, Username,Mytime,Domain,
                                    get_html_text("080"));
                            }
                        
                        } else {
                            fprintf(actout,"<A href=%s/com/moduser?user=%s&time=%i&dom=%s&moduser=%s>\
<FONT SIZE=2 COLOR=BLACK><B>%s %s</B></a><BR><BR>\n",
                                CGIPATH, Username,Mytime,Domain,
                                Username, get_html_text("111"), Username);

                        }

                        if (AdminType==SYSTEM_ADMIN||AdminType==DOMAIN_ADMIN){
                            fprintf(actout,
                                "<BR><FONT SIZE=2 COLOR=red><B>%s</B><BR>\n",
                                get_html_text("124"));
                            if (MaxPopAccounts !=0 ) {
                                fprintf(actout,"<A href=%s/com/adduser?user=%s&time=%i&dom=%s&>\
<FONT SIZE=2 COLOR=BLACK><B>%s</B></a><BR>\n",
                                CGIPATH, Username,Mytime,Domain,
                                get_html_text("125"));
                            }
                            if (MaxAliases !=0 ) {
                                fprintf(actout,"<A href=%s/com/adddotqmail?atype=alias&user=%s&time=%i&dom=%s&>\
<FONT SIZE=2 COLOR=BLACK><B>%s</B></a><BR>\n",
                                CGIPATH, Username,Mytime,Domain,
                                get_html_text("126"));
                            }
                            if (MaxForwards !=0 ) {
                                fprintf(actout,"<A href=%s/com/adddotqmail?atype=forward&user=%s&time=%i&dom=%s&>\
<FONT SIZE=2 COLOR=BLACK><B>%s</B></a><BR>\n",
                                    CGIPATH, Username,Mytime,Domain,
                                    get_html_text("127"));
                            }
                            if (MaxAutoResponders !=0 ) {
                                fprintf(actout,"<A href=%s/com/addautorespond?user=%s&time=%i&dom=%s&>\
<FONT SIZE=2 COLOR=BLACK><B>%s</B></a><BR>\n",
                                CGIPATH, Username,Mytime,Domain,
                                get_html_text("128"));
                            }
                            if (MaxMailingLists !=0 ) {
                                fprintf(actout,"<A href=%s/com/addmailinglist?user=%s&time=%i&dom=%s&>\
<FONT SIZE=2 COLOR=BLACK><B>%s</B></a><BR>\n",
                                CGIPATH, Username,Mytime,Domain,
                                get_html_text("129"));
                            }
                        }
                        break;
                    
                    /* show the lines inside a alias table */
                    case 'b':
                        show_dotqmail_lines(Username,Domain,Mytime,RealDir,"alias");
                        break;

                    /* show the lines inside a mailing list table */
                    case 'c':
                        show_mailing_list_line2(Username,Domain,Mytime,RealDir);
                        break;

                    /* show the lines inside a forward table */
                    case 'd':
                        show_dotqmail_lines(Username,Domain,Mytime,RealDir,"forward");
                        break;

                    /* show the lines inside a mailing list table */
                    case 'e':
                        show_mailing_list_line(Username,Domain,Mytime,RealDir);
                        break;

                    /* this will be used to parse mod_mailinglist-idx.html */
                    case 'E':
                        /* not written yet  ;) */

                    /* show the forwards */
                    case 'f':
                        if ( AdminType == SYSTEM_ADMIN || 
                             AdminType == DOMAIN_ADMIN ) {
                            show_forwards(Username,Domain,Mytime,RealDir);
                        }
                        break;

                    /* show the lines inside a autorespond table */
                    case 'g':
                        show_autorespond_line(Username,Domain,Mytime,RealDir);
                        break;

                    /* show the counts */
                    case 'h':
                        show_counts();
                        break;

                    /* check for user forward and forward/store vacation */
                    case 'i':
                       check_user_forward_vacation(fgetc(fs));
                       break;
                       break;

                    /* show the counts */
                    case 't':
                        show_main_table();
                        break;

                    /* show the users */
                    case 'u':
                        show_users(Username,Domain,Mytime,RealDir);
                        break;

                    /* show the aliases stuff */
                    case 'l':
                        if ( AdminType == SYSTEM_ADMIN || 
                             AdminType == DOMAIN_ADMIN ) {
                            show_aliases(Username,Domain,Mytime,RealDir);
                        }
                        break;


                    /* show the mailing lists */
                    case 'm':
                        if ( AdminType == SYSTEM_ADMIN || 
                             AdminType == DOMAIN_ADMIN ) {
                            show_mailing_lists(Username,Domain,Mytime,RealDir);
                        }
                        break;

                    /* show the mailing list subscribers */
                    case 'M':
                        if ( AdminType == SYSTEM_ADMIN || 
                             AdminType == DOMAIN_ADMIN ) {
                            show_list_users_now();
                        }
                        break;

                    /* show the mailing list moderators */
                    case 'o':
                        if ( AdminType == SYSTEM_ADMIN || 
                             AdminType == DOMAIN_ADMIN ) {
                            show_list_moderators_now();
                        }
                        break;

                    /* show the autoresponder stuff */
                    case 'r':
                        if ( AdminType == SYSTEM_ADMIN || 
                             AdminType == DOMAIN_ADMIN ) {
                            show_autoresponders(Username,Domain,Mytime,RealDir);
                        }
                        break;

                    /* send the CGIPATH parameter */
                    case 'C':
                        fprintf(actout,"%s", CGIPATH);
                        break;
    
                    /* send the Alias parameter */
                    case 'a':
                        fprintf(actout,"%s", Alias);
                        break;
                    case 'I':
                        show_dotqmail_file(ActionUser);
                        break;
                
                    /* send the action user parameter */
                    case 'A':
                        fprintf(actout,"%s", ActionUser);
                        break;

                    /* send the domain parameter */
                    case 'D':
                        fprintf(actout,"%s", Domain);
                        break;

                    /* send the username parameter */
                    case 'U':
                        fprintf(actout,"%s", Username);
                        break;

                    /* send the time parameter */
                    case 'T':
                        fprintf(actout,"%d", Mytime);
                        break;

                    /* send the status message parameter */
                    case 'S':
                        fprintf(actout,"%s", StatusMessage);
                        break;

                    /* show the catchall name */
                    case 's':
                        get_catchall();
                        break;

                    /* display a file */
                    case 'F':
                        {
                         FILE *fs;
                        sprintf(TmpBuf, ".qmail-%s", ActionUser);
			for(i=6;TmpBuf[i]!=0;++i) if ( TmpBuf[i] == '.' ) TmpBuf[i] = ':';
                        if ( (fs = fopen(TmpBuf, "r")) == NULL ) 
                                ack("123", 123);
                        fgets( TmpBuf2, MAX_BUFF, fs);
                        if ( fgets( TmpBuf2, MAX_BUFF, fs) ) {
                            /* See if it's a Maildir path rather than address */
                                    i = strlen(TmpBuf2) - 2;
                            if ( TmpBuf2[i] == '/' ) {
                                --i; for(;TmpBuf2[i]!='/';--i);
                                --i; for(;TmpBuf2[i]!='/';--i);
                                for(++i,j=0;TmpBuf2[i]!='/';++j,++i) TmpBuf3[j] = TmpBuf2[i];
                                TmpBuf3[j] = '\0';
                                fprintf(actout, "value=\"%s@%s\"> <td>\n",TmpBuf3,Domain);
                            } else {
                                fprintf(actout, "value=\"%s\"> <td>\n",&TmpBuf2[1]);
                            }
                        } 
                        fclose(fs);

                        upperit(ActionUser);

                        sprintf(TmpBuf, "%s/message", ActionUser);
                        if ( (fs = fopen(TmpBuf, "r")) == NULL ) 
                            ack("123", 123);
                        fgets( TmpBuf2, MAX_BUFF, fs);
                        fgets( TmpBuf2, MAX_BUFF, fs);
                        fprintf(actout,"\
                        <td> &nbsp; </td> </tr>\n\
                        <tr> <td>Subject:&nbsp; </td>\n\
                        <td> <input type=text size=40 name=alias maxlength=128 value=\"%s\"> <td>\n",
                            &TmpBuf2[9]);
                        
                        fprintf(actout,"\
                        <td> <input type=submit value=Modify name=do.login> </td> </tr>\
                        </tbody>\n\
                        </table>\n\
                        </td>\n\
                        </tr>\n\
                        </tbody>\n\
                        </table>\n");

                            fprintf(actout,"\
                                <textarea cols=80 rows=40 name=message>\n");

                            fgets( TmpBuf2, MAX_BUFF, fs);
                            while( fgets( TmpBuf2, MAX_BUFF, fs) ) {
                                fprintf(actout, "%s", TmpBuf2);
                            }

                            fprintf(actout, "</textarea>\n");
                            fclose(fs);
                        }
                        break;
                    case 'O':
                        {
                        struct vqpasswd *pw;

                        pw = vauth_getall(Domain,1,0);
                        while( pw != NULL ) {
                                 fprintf(actout,"<option value=%s>%s\n", 
                                    pw->pw_name, pw->pw_name);
                            pw = vauth_getall(Domain,0,0);
                        }
                        }
                        break;

                    default:
                        break;
                }
                

            /* 
             * didn't find a tag, so send out the first '#' and the
             * current character 
             */
            } else {
                fputc('#', actout);
                fputc(inchar, actout);
            }
        } 
    }
    fclose(fs);
    fflush(actout);
        vclose();
}

void check_user_forward_vacation(char newchar)
{
 static struct vqpasswd *vpw = NULL;
 static FILE *fs1=NULL; /* for the .qmail file */
 static FILE *fs2=NULL; /* for the vacation message file */
 int i;

  if ( vpw==NULL ) vpw = vauth_getpw(ActionUser, Domain); 
  if ( fs1== NULL ) {
    snprintf(NTmpBuf,156, "%s/.qmail", vpw->pw_dir);
    fs1 = fopen(NTmpBuf,"r");
  }
  if ( fs1 == NULL ) return;

  /* start at the begingin if second time thru */
  rewind(fs1);


  if ( fgets(NTmpBuf,156,fs1)!=NULL){
                           
    /* if it is a forward to a program */
    if (strstr(NTmpBuf, "autorespond")!=NULL ) {
      if ( newchar=='2' ) {
          printf("CHECKED ");
      } else if ( newchar=='4' ) {
          if ( fs2 == NULL ) { 
              snprintf(NTmpBuf,156, "%s/vacation/message", vpw->pw_dir);
              fs2 = fopen(NTmpBuf,"r");
          }
          if ( fs2 != NULL ) {
                rewind(fs2);
                /* it's a hack, the second line always has 
                 * the subject 
                 */
		fgets(NTmpBuf,156,fs2);
		fgets(NTmpBuf,156,fs2);
                printf("%s", &NTmpBuf[9]);
          }
      } else if ( newchar=='5') {
          if ( fs2 == NULL ) { 
              snprintf(NTmpBuf,156, "%s/vacation/message", vpw->pw_dir);
              fs2 = fopen(NTmpBuf,"r");
          }
          if ( fs2 != NULL ) {
                rewind(fs2);
		for(i=0;i<3&& fgets(NTmpBuf,156,fs2)!=NULL;++i);
                while( fgets(NTmpBuf,156,fs2)!=NULL ) {
                   printf("%s", NTmpBuf);
                }
	  }
      }
      return;

    } else {
       if ( newchar == '3') {
	    if ( NTmpBuf[0] == '&' ) {
		   printf("%s", &NTmpBuf[1]);
        } else {
		   printf("%s", NTmpBuf);
	    } 
        return;
       }

      /* if there is a second line and 
       * we are looking for store and forward
       * then we found it
       */
      if ( fgets(NTmpBuf,156,fs1)!=NULL ) {
        if ( newchar=='1' ){
            printf("CHECKED ");
        }
        return;

      /* if no second line and we are looking
       * for just a forward, then we found it
       */
      } else if ( newchar == '0' ) {
        printf("CHECKED ");
      }
    }
  } 
}
