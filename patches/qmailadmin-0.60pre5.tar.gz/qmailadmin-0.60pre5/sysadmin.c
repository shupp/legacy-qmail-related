/* QmailAdmin 
 * Copyright (C) 1999 Inter7 Internet Technologies, Inc. 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pwd.h>
#include <dirent.h>
#include "config.h"
#include "qmailadmin.h"
#include "qmailadminx.h"

#define MAX_CONTROL_FILES 28
char *ControlFiles[MAX_CONTROL_FILES][4] = {
"badmailfrom",		"(none)",		"qmail-smtpd",	"y",
"bouncefrom",		"MAILER-DAEMON",	"qmail-send",   "y",
"bouncehost",		"me",			"qmail-send",   "y",
"concurrencylocal",	"10",			"qmail-send",   "y",
"concurrencyremote",	"20",			"qmail-send",   "y",
"defaultdomain",	"me",			"qmail-inject", "y",
"defaulthost",		"me",			"qmail-inject", "y",
"databytes",		"0",			"qmail-smtpd",  "y",
"doublebouncehost",	"me",			"qmail-send",   "y",
"doublebounceto",	"postmaster",		"qmail-send",   "y",
"envnoathost",		"me",			"qmail-send",   "y",
"helohost",		"me",			"qmail-remote", "y",
"idhost",		"me",			"qmail-inject", "y",
"localiphost",		"me",			"qmail-smtpd",  "y",
"locals",		"me",			"qmail-send",   "n",
"me",			"(none)",		"??",  		"y",
"morercpthosts",	"(none)",		"qmail-smtpd",  "n",
"percenthack",		"(none)",		"qmail-send",   "y",
"plusdomain",		"me",			"qmail-inject", "y",
"qmqpservers",		"(none)",		"qmail-qmqpc",  "n",
"queuelifetime",	"604800",		"qmail-send",   "y",
"rcpthosts",		"(none)",		"qmail-smtpd",  "n",
"smtpgreeting",		"me",			"qmail-smtpd",  "n",
"smtproutes",		"(none)",		"qmail-remote", "n",
"timeoutconnect",	"60",			"qmail-remote", "y",
"timeoutremote",	"1200",			"qmail-remote", "y",
"timeoutsmtpd",		"1200",			"qmail-smtpd",  "y",
"virtualdomains",	"(none)",		"qmail-send",  "n"
};

show_domain_admin()
{
	fprintf(actout,
		"<a href=%s/com/adddomain?user=%s&time=%d>Add Domain</a><BR>\n",
		CGIPATH, Username, Mytime);
	fprintf(actout,
		"<a href=%s/com/deldomain?user=%s&time=%d>Delete Domain</a><BR>\n",
		CGIPATH, Username, Mytime);
}


show_domains()
{
 DIR *mydir;
 struct dirent *mydirent;

	mydir = opendir(".");
	if ( mydir == NULL ) ack ("Failed to opendir()",302);

	fprintf(actout, "Domains<BR>\n");
        while((mydirent=readdir(mydir))!=NULL){
                if ( strncmp(mydirent->d_name,".", 2)!=0 &&
                     strncmp(mydirent->d_name,"..", 3)!=0 ) {
			fprintf(actout,
"<a href=%s/com/enterdomain?user=%s&dom=%s&time=%d>%s</a><BR>\n",
				CGIPATH, Username,mydirent->d_name,
				Mytime,mydirent->d_name);
                }
        }
	closedir(mydir);
}

enterdomain()
{


}

show_controls()
{
 int i,j;

	fprintf(actout, "Control Files<BR>\n");
	fprintf(actout, "<table>\n");

	fprintf(actout,
"<tr><th>control</th><th>default</th><th>used by</th><th>current value</th>\n");

	for(i=0;i<MAX_CONTROL_FILES;++i) {
		fprintf(actout,"<tr>");
		for(j=0;j<3;++j) {
			fprintf(actout,"<td>%s</td>", ControlFiles[i][j]);
		}
		fprintf(actout,"\n");
		if ( strcmp(ControlFiles[i][3], "y") == 0 ) {
			get_file_contents(ControlFiles[i][0]);
		} else {
			show_file_contents_link(ControlFiles[i][0]);
		}
	}
	fprintf(actout,"</table>\n");

}


show_status()
{

}

show_man_pages_index()
{
 DIR *mydir;
 struct dirent *mydirent;

	fprintf(actout, "Man 1<BR>\n");
	strcpy(TmpBuf2, QMAILDIR); 
	strcat(TmpBuf2, "/man/cat1");
	put_index(TmpBuf2);

	fprintf(actout, "Man 5<BR>\n");
	strcpy(TmpBuf2, QMAILDIR); 
	strcat(TmpBuf2, "/man/cat5");
	put_index(TmpBuf2);

	fprintf(actout, "Man 7<BR>\n");
	strcpy(TmpBuf2, QMAILDIR); 
	strcat(TmpBuf2, "/man/cat7");
	put_index(TmpBuf2);

	fprintf(actout, "Man 8<BR>\n");
	strcpy(TmpBuf2, QMAILDIR); 
	strcat(TmpBuf2, "/man/cat8");
	put_index(TmpBuf2);

}

put_index(directory)
 char *directory;
{
 DIR *mydir;
 struct dirent *mydirent;

	mydir = opendir(directory);
	if ( mydir == NULL ) ack ("Failed to opendir()",302);
        while((mydirent=readdir(mydir))!=NULL){
                if ( strncmp(mydirent->d_name,".", 2)!=0 &&
                     strncmp(mydirent->d_name,"..", 3)!=0 ) {
			fprintf(actout, 
"<a href=%s/open/showfile?user=%s&dom=%s&time=%d&manpage=%s&dir=%s>%s</a><BR>\n",
				CGIPATH, Username,Domain, Mytime,
				mydirent->d_name, directory,
				mydirent->d_name);
		}
	}
	closedir(mydir);
}

show_file()
{
 FILE *fs;
 char *p,*p2;

	if ( strstr( ActionUser, QMAILDIR ) != NULL ) {
		vclose();
		exit(0);
	}

	sprintf(TmpBuf2, "%s/%s", ActionUser, Message);
	fprintf(actout,"<PRE>\n");
	fs = fopen(TmpBuf2, "r");
	if ( fs == NULL ) {
		fprintf(actout, "Could not find man page file %s<BR>\n",
			TmpBuf2);
		vclose();
		exit(0);
	}
	while ( fgets(TmpBuf,MAX_BUFF,fs) != NULL ) {
		while ( (p=strstr(TmpBuf,"")) ) {
			--p;
			p2 = p+2;
			memmove(p,p2,strlen(p2)+1);
		}
                fputs(TmpBuf,actout);
		fprintf(actout, "<BR>");
    }
	fprintf(actout,"</PRE>\n");
	
}


get_file_contents(control_file)
 char *control_file;
{
 FILE *fs;

	sprintf(TmpBuf2, "%s/control/%s", QMAILDIR, control_file);
	fs = fopen(TmpBuf2, "r");
	if ( fs == NULL ) {
		fprintf(actout,"<td>default</td>");
		return(0);
	}
        if ( fgets(TmpBuf,MAX_BUFF,fs) != NULL ) {
		fprintf(actout,"<td>%s</td>", TmpBuf);
	} else {
		fprintf(actout,"<td>default</td>");
	}
	fclose(fs);
}

show_file_contents_link(control_file)
 char *control_file;
{
 FILE *fs;

	sprintf(TmpBuf2, "%s/control/%s", QMAILDIR, control_file);
	fs = fopen(TmpBuf2, "r");
	if ( fs == NULL ) {
		fprintf(actout,"<td>no file</td>");
		return(0);
	}
	fprintf(actout, 
"<td><a href=%s/open/showfile?user=%s&dom=%s&time=%d&manpage=%s&dir=%s%s>link</a></td>\n",
				CGIPATH, Username,Domain, Mytime,
				control_file, QMAILDIR, "/control");
	fclose(fs);
}

add_domain()
{
	fprintf(actout, "add a domain<BR>\n");

}

del_domain()
{
	fprintf(actout, "del a domain<BR>\n");
}
