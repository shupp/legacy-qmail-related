/* QmailAdmin 
 * Copyright (C) 1999 Inter7 Internet Technologies, Inc. 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pwd.h>
#include <dirent.h>
#include "config.h"
#include "qmailadmin.h"
#include "qmailadminx.h"
#include <errno.h>



show_mailing_lists(user,dom,mytime,dir)
 char *user;
 char *dom;
 time_t mytime;
 char *dir;
{
	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

 	if ( MaxMailingLists == 0 ) {
		return(0);
	}
	send_template( "show_mailinglist.html" );
}

show_mailing_list_line(user,dom,mytime,dir)
 char *user;
 char *dom;
 time_t mytime;
 char *dir;
{
 DIR *mydir;
 struct dirent *mydirent;
 FILE *fs;
 char mailinglist_name[MAX_FILE_NAME];
 int i,j;

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

 	if ( MaxMailingLists == 0 ) {
		return(0);
	}

	if ( (mydir = opendir(".")) == NULL ) {
		fprintf(actout,"%s %d<BR>\n", get_html_text("143"), 1);
		fprintf(actout,"</table>");
		return(0);
	}

	/* First display the title row */
	fprintf(actout, "<TR>\n");
#ifdef EZMLMIDX
        fprintf(actout, "  <TH>%s<br><font size=-1>%s</font></TH>\n", get_html_text("081"), get_html_text("224"));
#else
        fprintf(actout, "  <TH>%s</TH>\n", get_html_text("081"));
#endif
        fprintf(actout, "  <TH>%s</TH>\n", get_html_text("072"));
        fprintf(actout, "  <TH>%s</TH>\n", get_html_text("083"));
        fprintf(actout, "  <TH>%s</TH>\n", get_html_text("084"));
        fprintf(actout, "  <TH>%s</TH>\n", get_html_text("085"));
#ifdef EZMLMIDX
        fprintf(actout, "  <TH>%s</TH>\n", get_html_text("086"));
        fprintf(actout, "  <TH>%s</TH>\n", get_html_text("087"));
        fprintf(actout, "  <TH>%s</TH>\n", get_html_text("088"));
#endif
        fprintf(actout, "</TR>\n");
 

	/* Now, display each list */
	while( (mydirent=readdir(mydir)) != NULL ) {
		if ( strncmp(".qmail-", mydirent->d_name, 7) == 0 ) {
			if ( (fs=fopen(mydirent->d_name,"r"))==NULL) {
				fprintf(actout,"%s %s<br>\n", get_html_text("144"),
					mydirent->d_name);
				continue;
			}
			fgets( TmpBuf2, MAX_BUFF, fs);
			if ( strstr( TmpBuf2, "ezmlm-reject") != 0 ) {

				for(i=7,j=0;j<MAX_FILE_NAME-1&&mydirent->d_name[i]!=0;++i,++j) {
					mailinglist_name[j] = mydirent->d_name[i];
				}
				mailinglist_name[j] = 0;

#ifdef EZMLMIDX
				fprintf(actout,"<TR>\n  <TD align=middle><a href=%s/com/modmailinglist?user=%s&dom=%s&time=%d&modu=%s>%s@%s</a></TD>\n", 
					CGIPATH, user, Domain, mytime, mailinglist_name, mailinglist_name, Domain); 
#else
				fprintf(actout,"<TR>\n  <TD align=middle>%s@%s</TD>\n", 
					mailinglist_name, Domain); 
#endif

				fprintf(actout,"  <TD align=center><A href=%s/com/delmailinglist?user=%s&dom=%s&time=%d&modu=%s><img src=\"/images/qmailadmin/delete.gif\" border=0></a></TD>\n",
					CGIPATH, user, dom, mytime, mailinglist_name);

				fprintf(actout,
"  <TD align=center><A href=%s/com/addlistuser?user=%s&dom=%s&time=%d&modu=%s><img src=\"/images/qmailadmin/delete.gif\" border=0></a></TD>\n",
					CGIPATH, user, dom, mytime, mailinglist_name);

				fprintf(actout,
"  <TD align=center><A href=%s/com/dellistuser?user=%s&dom=%s&time=%d&modu=%s><img src=\"/images/qmailadmin/delete.gif\" border=0></a></TD>\n",
					CGIPATH, user, dom, mytime, mailinglist_name);

				fprintf(actout,
"  <TD align=center><A href=%s/com/showlistusers?user=%s&dom=%s&time=%d&modu=%s><img src=\"/images/qmailadmin/delete.gif\" border=0></a></TD>\n",
					CGIPATH, user, dom, mytime, mailinglist_name);

#ifdef EZMLMIDX
				fprintf(actout,
"  <TD align=center><A href=%s/com/addlistmod?user=%s&dom=%s&time=%d&modu=%s><img src=\"/images/qmailadmin/delete.gif\" border=0></a></TD>\n",
					CGIPATH, user, dom, mytime, mailinglist_name);

				fprintf(actout,
"  <TD align=center><A href=%s/com/dellistmod?user=%s&dom=%s&time=%d&modu=%s><img src=\"/images/qmailadmin/delete.gif\" border=0></a></TD>\n",
					CGIPATH, user, dom, mytime, mailinglist_name);

				fprintf(actout,
"  <TD align=center><A href=%s/com/showlistmod?user=%s&dom=%s&time=%d&modu=%s><img src=\"/images/qmailadmin/delete.gif\" border=0></a></TD>\n",
					CGIPATH, user, dom, mytime, mailinglist_name);
#endif
				fprintf(actout, "</TR>\n");

			}
			fclose(fs);
		}
	}
	closedir(mydir);

}

is_mailing_list(fs)
 FILE *fs;
{
       while (!feof(fs)) {
               fgets( TmpBuf2, MAX_BUFF, fs);
               if ( strstr( TmpBuf2, "ezmlm-reject") != 0 ||
                    strstr( TmpBuf2, "ezmlm-send")   != 0 )
                       return -1;
       }
       return 0;
}

show_mailing_list_line2(user,dom,mytime,dir)
 char *user;
 char *dom;
 time_t mytime;
 char *dir;
{
 DIR *mydir;
 struct dirent *mydirent;
 FILE *fs;
 char mailinglist_name[MAX_FILE_NAME];
 int i,j, cnt = 0;

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

 	if ( MaxMailingLists == 0 ) {
		return(0);
	}

    if ( (mydir = opendir(".")) != NULL){
		while( (mydirent = readdir(mydir)) != NULL)
			if( strncmp(".qmail-", mydirent->d_name, 7) == 0){
				if( (fs = fopen(mydirent->d_name, "r")) == NULL){
					fprintf(actout,"%s %s<br>\n", get_html_text("144"),
						mydirent->d_name);
					continue;
				}
				if (is_mailing_list(fs)) num_of_mailinglist++;
				fclose(fs);
			}
		closedir(mydir);
	}
	fprintf(actout, "<INPUT NAME=number_of_mailinglist TYPE=hidden VALUE=%d>\n", num_of_mailinglist);

	if ( (mydir = opendir(".")) == NULL ) {
		fprintf(actout,"%s %d<BR>\n", get_html_text("143"), 1);
		fprintf(actout,"</table>");
		return(0);
	}

    cnt = 0;
	while( (mydirent=readdir(mydir)) != NULL ) {
		if ( strncmp(".qmail-", mydirent->d_name, 7) == 0 ) {
			if ( (fs=fopen(mydirent->d_name,"r"))==NULL) {
				fprintf(actout,"%s %s<br>\n", get_html_text("144"),
					mydirent->d_name);
				continue;
			}
			fgets( TmpBuf2, MAX_BUFF, fs);
			if ( strstr( TmpBuf2, "ezmlm-reject") != 0 ) {

				for(i=7,j=0;j<MAX_FILE_NAME-1&&mydirent->d_name[i]!=0;++i,++j) {
					mailinglist_name[j] = mydirent->d_name[i];
				}
				mailinglist_name[j] = 0;

	            fprintf(actout,"<TR><TD align=center>%s@%s</TD><TD \
align=center><INPUT NAME=\"subscribe%d\" TYPE=\"checkbox\" \
VALUE=%s></TD></TR>", mailinglist_name, Domain, cnt++, mailinglist_name); 
              
			}
			fclose(fs);
		}
	}
	closedir(mydir);

}


addmailinglist()
{
	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	count_mailinglists();
	load_limits();
	if ( MaxMailingLists != -1 && CurMailingLists >= MaxMailingLists ) {
		fprintf(actout, "%s %d\n", get_html_text("184"), 
			MaxMailingLists);
		show_menu();
		vclose();
		exit(0);
	}
#ifdef EZMLMIDX
	send_template( "add_mailinglist-idx.html" );
#else
	send_template( "add_mailinglist-no-idx.html" );
#endif

}

delmailinglist()
{
	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	send_template( "del_mailinglist_confirm.html" );
}

delmailinglistnow()
{
 int pid;
 DIR *mydir;
 struct dirent *mydirent;

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	if ( (mydir = opendir(".")) == NULL ) {
		fprintf(actout,"%s %d<BR>\n", get_html_text("143"), 1);
		fprintf(actout,"</table>");
		return(0);
	}
 
	sprintf(TmpBuf2, ".qmail-%s", ActionUser);
	sprintf(TmpBuf3, ".qmail-%s-", ActionUser);
	while( (mydirent=readdir(mydir)) != NULL ) {

		/* delete the main .qmail-"list" file */
		if ( strcmp(TmpBuf2, mydirent->d_name) == 0 ) {
			if ( unlink(mydirent->d_name) != 0 ) {
				ack(get_html_text("185"), TmpBuf2);
			}

		/* delete secondary .qmail-list"-* files */
		} else if ( strncmp(TmpBuf3, mydirent->d_name, strlen(TmpBuf3)) == 0 ) {
			if ( unlink(mydirent->d_name) != 0 ) {
				ack(get_html_text("185"), TmpBuf2);
			}
		}
	}
	closedir(mydir);


	sprintf(TmpBuf2, "%s/%s", RealDir, ActionUser);
	vdelfiles(TmpBuf2);

	sprintf(StatusMessage, "%s %s\n", get_html_text("186"), ActionUser);
	show_mailing_lists(Username, Domain, Mytime);

}


addmailinglistnow()
{
	FILE * file;
	int pid;

#ifdef EZMLMIDX
	char list_owner[MAX_BUFF];
	char owneremail[MAX_BUFF+5];	
#endif
	char options[MAX_BUFF];
	char *arguments[MAX_BUFF];
	int i=0;
	char tmp[MAX_BUFF];
	char *tmpstr;
	char loop_ch[MAX_BUFF];
	int  loop;
	int  num_choices;

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}


	if ( fixup_local_name(ActionUser) ) {
		sprintf(StatusMessage, "%s %s\n", get_html_text("188"), ActionUser);
		addmailinglist();
		vclose();
		exit(0);
	}
	if ( check_local_user(ActionUser) ) {
		sprintf(StatusMessage, "%s %s\n", get_html_text("175"), ActionUser);
		addmailinglist();
		vclose();
		exit(0);
	}


	memset(options, 0, MAX_BUFF);
	memset(loop_ch, 0, MAX_BUFF);

#ifdef EZMLMIDX
	/* check the list owner entry */
	GetValue(TmpCGI, list_owner, "listowner=", MAX_BUFF); // Get the listowner
	memset(owneremail, 0, MAX_BUFF);
	if ( strlen(list_owner) > 0 ) {
		strcpy( owneremail, "-5");
		strcat( owneremail, list_owner);
	}
#endif

#ifdef EZMLMIDX
	num_choices = NUM_EZMLM_IDX_CHOICES;
#else
	num_choices = NUM_EZMLM_NO_IDX_CHOICES;
#endif

	memset(options, 0, MAX_BUFF);
	for(loop = 0; loop < num_choices; loop++) {	
		sprintf(tmp, "param%d=", loop);
		memset(loop_ch, 0, MAX_BUFF);
		GetValue(TmpCGI, loop_ch, tmp, MAX_BUFF);

		if ( strlen(loop_ch) > 0 ) {
			strcat(options, loop_ch);
			strcat(options, " ");
		}
	}

#ifdef EZMLMIDX
	/* check for sql support */
	memset(tmp, 0, MAX_BUFF);
	GetValue(TmpCGI, tmp, "sqlsupport=", MAX_BUFF);
	if( strlen(tmp) > 0 ) {
		strcat(options, tmp);
		strcat(options, " ");
		for(loop = 0; loop < NUM_SQL_OPTIONS; loop++) {	
			sprintf(tmp, "sql%d=", loop+1);
			memset(loop_ch, 0, MAX_BUFF);
			GetValue(TmpCGI, loop_ch, tmp, MAX_BUFF);
			if ( strlen( loop_ch ) > 0 ) {
				strcat(options, loop_ch);
	    		if(loop < NUM_SQL_OPTIONS - 1) strcat(options, ":");
			}
		}
	}
#endif

	pid=fork();
	if (pid==0) {
		sprintf(TmpBuf1, "%s/ezmlm-make", EZMLMDIR);
		sprintf(TmpBuf2, "%s/%s", RealDir, ActionUser);
		sprintf(TmpBuf3, "%s/.qmail-%s", RealDir, ActionUser);
		i = 0;
		arguments[i++] = "ezmlm-make";

#ifdef EZMLMIDX
		if ( strlen(owneremail) > 0 ) arguments[i++]=owneremail;
#endif

		for(tmpstr=strtok(options," ");tmpstr!=NULL;tmpstr=strtok(NULL," ")){
			arguments[i++] = tmpstr;
		}
		arguments[i++]=TmpBuf2;
		arguments[i++]=TmpBuf3;
		arguments[i++]=ActionUser;
		arguments[i++]=Domain;
		arguments[i++]=NULL;

		execv(TmpBuf1, arguments);
		exit(127);
	} else {
		wait(&pid);
	}

	sprintf(TmpBuf, "%s/%s/inlocal",
		RealDir, ActionUser);

  	file=fopen(TmpBuf , "w");
	fprintf(file, "%s-%s", Domain, ActionUser);
	fclose(file);

	sprintf(StatusMessage, "%s %s@%s\n", get_html_text("187"), 
		ActionUser, Domain);
	show_mailing_lists(Username, Domain, Mytime);

}



show_list_users()
{
        if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
                sprintf(StatusMessage,"%s", get_html_text("142"));
                vclose();
                exit(0);
        }

        if ( MaxMailingLists == 0 ) {
                return(0);
        }
        send_template( "show_subscribers.html" );
}



show_list_users_now()
{
 FILE *fs;
 int i,handles[2],pid;

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	fprintf(actout, "<b>%s %s@%s</b><p>\n", get_html_text("189"), 
		ActionUser, Domain);

	fprintf(actout,
"<a href=%s/com/showmailinglists?user=%s&dom=%s&time=%d&>%s</a>&nbsp;\n", 
		CGIPATH, Username,Domain,Mytime, get_html_text("080"));
	fprintf(actout,
"<a href=%s/com/showmenu?user=%s&dom=%s&time=%d&>%s</a><p>", 
		CGIPATH, Username,Domain,Mytime, get_html_text("001"));

	lowerit(ActionUser);
	pipe(handles);

	pid=fork();
	if (pid==0) {
		close(handles[0]);
		dup2(handles[1],fileno(stdout));
		sprintf(TmpBuf1, "%s/ezmlm-list", EZMLMDIR);
		sprintf(TmpBuf2, "%s/%s", RealDir, ActionUser);
		execl(TmpBuf1, "ezmlm-list", TmpBuf2, NULL);
		exit(127);
	} else {
                close(handles[1]);
		fs = fdopen(handles[0],"r");

		/* Display subsriber list, along with delete button */
		fprintf(actout,"<TABLE border=0>");
		fprintf(actout,"    <TR>");
		fprintf(actout,"        <TD align=middle><b>%s</b></TD>", get_html_text("222"));
		fprintf(actout,"        <TD align=middle><b>%s</b></TD>", get_html_text("084"));
		fprintf(actout,"    </TR>");
		while( fgets(TmpBuf1, MAX_BUFF, fs )!=NULL){
			i = strlen(TmpBuf1); --i; TmpBuf1[i] = 0; /* take off newline */
			fprintf(actout,"    <TR>");
			fprintf(actout,"        <TD>%s</TD>", TmpBuf1);
			fprintf(actout,"        <TD align=middle><A href=%s/com/dellistusernow?modu=%s&newu=%s&dom=%s&user=%s&time=%d><IMG src=/images/qmailadmin/delete.gif border=0></A></TD>\n",
				CGIPATH, ActionUser, TmpBuf1, Domain, Username, Mytime);
			fprintf(actout,"    </TR>");
		}
		fprintf(actout,"</TABLE>");
		fclose(fs); close(handles[0]);
        wait(&pid);
		sprintf(StatusMessage, "%s\n", get_html_text("190"));
		fprintf(actout, get_html_text("END_LIST_NAMES"));
	}
}

show_list_moderators()
{
        if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
                sprintf(StatusMessage,"%s", get_html_text("142"));
                vclose();
                exit(0);
        }

        if ( MaxMailingLists == 0 ) {
                return(0);
        }
        send_template( "show_moderators.html" );
}

show_list_moderators_now()
{
 FILE *fs;
 int i,handles[2],pid;

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	fprintf(actout, "<b>%s %s@%s</b><p>\n", get_html_text("191"), 
		ActionUser, Domain);

        fprintf(actout,
"<a href=%s/com/showmailinglists?user=%s&dom=%s&time=%d&>%s</a>&nbsp;\n", 
                CGIPATH, Username,Domain,Mytime, get_html_text("080"));
        fprintf(actout,
"<a href=%s/com/showmenu?user=%s&dom=%s&time=%d&>%s</a><p>", 
                CGIPATH, Username,Domain,Mytime, get_html_text("001"));

	lowerit(ActionUser);
	pipe(handles);

	pid=fork();
	if (pid==0) {
		close(handles[0]);
		dup2(handles[1],fileno(stdout));
		sprintf(TmpBuf1, "%s/ezmlm-list", EZMLMDIR);
		sprintf(TmpBuf2, "%s/%s/mod", RealDir, ActionUser);
		execl(TmpBuf1, "ezmlm-list", TmpBuf2, NULL);
		exit(127);
	} else {
                close(handles[1]);
		fs = fdopen(handles[0],"r");



                /* Display moderator list, along with delete button */
                fprintf(actout,"<TABLE border=0>");
                fprintf(actout,"    <TR>");
                fprintf(actout,"        <TD align=middle><b>%s</b></TD>", get_html_text("220"));
                fprintf(actout,"        <TD align=middle><b>%s</b></TD>", get_html_text("087"));
                fprintf(actout,"    </TR>");
		while( fgets(TmpBuf1, MAX_BUFF, fs )!=NULL){
                        i = strlen(TmpBuf1); --i; TmpBuf1[i] = 0; /* take off newline */
                        fprintf(actout,"    <TR>");
                        fprintf(actout,"        <TD>%s</TD>", TmpBuf1);
                        fprintf(actout,"        <TD align=middle><A href=%s/com/dellistmodnow?modu=%s&newu=%s&dom=%s&user=%s&time=%d><IMG src=/images/qmailadmin/delete.gif></A></TD>\n",
                                CGIPATH, ActionUser, TmpBuf1, Domain, Username, Mytime);
                        fprintf(actout,"    </TR>");
                }
                fprintf(actout,"</TABLE>");
		fclose(fs); close(handles[0]);
        wait(&pid);
		fprintf(actout, get_html_text("END_LIST_NAMES"));
	}
}


addlistuser()
{
	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}
	send_template( "add_listuser.html" );
}

addlistmod()
{
	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}
	send_template( "add_listmod.html" );
}

addlistusernow()
{
 int i, result;
 int pid;

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	lowerit(ActionUser);

	if ( check_email_addr(Newu) ) {
		sprintf(StatusMessage, "%s %s\n", get_html_text("148"), Newu);
		addlistuser();
		vclose();
		exit(0);
	}

	pid=fork();
	if (pid==0) {
		sprintf(TmpBuf1, "%s/ezmlm-sub", EZMLMDIR);
		sprintf(TmpBuf2, "%s/%s", RealDir, ActionUser);
		execl(TmpBuf1, "ezmlm-sub", TmpBuf2, Newu, NULL);
		exit(127);
	} else wait(&pid);

	sprintf(StatusMessage, "%s %s %s@%s\n", Newu, get_html_text("193"),
		ActionUser, Domain);
	show_mailing_lists(Username, Domain, Mytime);
	vclose();
	exit(0);
	

}

addlistmodnow()
{
 int i, result;
 int pid;

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	lowerit(ActionUser);

	if ( check_email_addr(Newu) ) {
		sprintf(StatusMessage, "%s %s\n", get_html_text("148"), Newu);
		addlistuser();
		vclose();
		exit(0);
	}

	pid=fork();
	if (pid==0) {
		sprintf(TmpBuf1, "%s/ezmlm-sub", EZMLMDIR);
		sprintf(TmpBuf2, "%s/%s/mod", RealDir, ActionUser);
		execl(TmpBuf1, "ezmlm-sub", TmpBuf2, Newu, NULL);
		exit(127);
	} else wait(&pid);

	sprintf(StatusMessage, "%s %s %s@%s\n", Newu, get_html_text("194"), 
		ActionUser, Domain);
	show_mailing_lists(Username, Domain, Mytime);
	vclose();
	exit(0);

}

dellistuser()
{
	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	send_template( "del_listuser.html" );

}

dellistmod()
{

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	send_template( "del_listmod.html" );

}

dellistusernow()
{
 int i;
 int pid;

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	lowerit(Newu);

	if ( check_email_addr(Newu) ) {
		sprintf(StatusMessage, "%s %s\n", get_html_text("148"), Newu);
		dellistuser();
		vclose();
		exit(0);
	}
	pid=fork();
	if (pid==0) {
		sprintf(TmpBuf1, "%s/ezmlm-unsub", EZMLMDIR);
		sprintf(TmpBuf2, "%s/%s", RealDir, ActionUser);
		execl(TmpBuf1, "ezmlm-unsub", TmpBuf2, Newu, NULL);
		exit(127);
	} else wait(&pid);

	sprintf(StatusMessage, "%s %s %s@%s\n", Newu, get_html_text("203"),
		ActionUser, Domain);
	show_mailing_lists(Username, Domain, Mytime);
	vclose();
	exit(0);
}
dellistmodnow()
{
 int i;
 int pid;

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	lowerit(Newu);

	if ( check_email_addr(Newu) ) {
		sprintf(StatusMessage, "%s %s\n", get_html_text("148"), Newu);
		dellistmod();
		vclose();
		exit(0);
	}
	pid=fork();
	if (pid==0) {
		sprintf(TmpBuf1, "%s/ezmlm-unsub", EZMLMDIR);
		sprintf(TmpBuf2, "%s/%s/mod", RealDir, ActionUser);
		execl(TmpBuf1, "ezmlm-unsub", TmpBuf2, Newu, NULL);
		exit(127);
	} else wait(&pid);

	sprintf(StatusMessage, "%s %s %s@%s\n", Newu, get_html_text("197"),
		ActionUser, Domain);
	show_mailing_lists(Username, Domain, Mytime);
		vclose();
	exit(0);
}
count_mailinglists()
{
 DIR *mydir;
 struct dirent *mydirent;
 FILE *fs;

	if ( (mydir = opendir(".")) == NULL ) {
		fprintf(actout,"%s %d<BR>\n", get_html_text("143"), 1);
		fprintf(actout,"</table>");
		return(0);
	}
 

	CurMailingLists = 0;
	while( (mydirent=readdir(mydir)) != NULL ) {
		if ( strncmp(".qmail-", mydirent->d_name, 7) == 0 ) {
			if ( (fs=fopen(mydirent->d_name,"r"))==NULL) {
				fprintf(actout, get_html_text("FAIL_PERM_ERROR"), 
					mydirent->d_name);
				continue;
			}
			fgets( TmpBuf2, MAX_BUFF, fs);
			if ( strstr( TmpBuf2, "ezmlm-reject") != 0 ) {
				++CurMailingLists;
			}
			fclose(fs);
		}
	}
	closedir(mydir);

}

modmailinglist()
{
 FILE *fs;

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	/* get the current listowner and copy it to Alias */
	sprintf(TmpBuf, ".qmail-%s-owner", ActionUser);
	if((fs=fopen(TmpBuf, "r"))!=NULL) {
		while(fgets(TmpBuf2, MAX_BUFF, fs)) {
			if(strstr(TmpBuf2, "@")!=NULL) {
				sprintf(Alias, "%s", TmpBuf2);
			}
		}
		fclose(fs);
	}

#ifdef EZMLMIDX
	send_template( "mod_mailinglist-idx.html" );
#else
	send_template( "show_mailinglists.html" );
#endif

}

modmailinglistnow()
{
	FILE * file;
	int pid;

#ifdef EZMLMIDX
	char list_owner[MAX_BUFF];
	char owneremail[MAX_BUFF+5];	
#endif
	char options[MAX_BUFF];
	char *arguments[MAX_BUFF];
	int i=0;
	char tmp[MAX_BUFF];
	char *tmpstr;
	char loop_ch[MAX_BUFF];
	int  loop;
	int  num_choices;

	if ( AdminType!=SYSTEM_ADMIN && AdminType!=DOMAIN_ADMIN ) {
		sprintf(StatusMessage,"%s", get_html_text("142"));
		vclose();
		exit(0);
	}

	if ( fixup_local_name(ActionUser) ) {
		sprintf(StatusMessage, "%s %s\n", get_html_text("188"), ActionUser);
		addmailinglist();
		vclose();
		exit(0);
	}

	memset(options, 0, MAX_BUFF);
	memset(loop_ch, 0, MAX_BUFF);

#ifdef EZMLMIDX
	/* check the list owner entry */
	GetValue(TmpCGI, list_owner, "listowner=", MAX_BUFF); // Get the listowner
	memset(owneremail, 0, MAX_BUFF);
	if ( strlen(list_owner) > 0 ) {
		strcpy( owneremail, "-5");
		strcat( owneremail, list_owner);
	}
#endif

#ifdef EZMLMIDX
	num_choices = NUM_EZMLM_IDX_CHOICES;
#else
	num_choices = NUM_EZMLM_NO_IDX_CHOICES;
#endif

	memset(options, 0, MAX_BUFF);
	for(loop = 0; loop < num_choices; loop++) {	
		sprintf(tmp, "param%d=", loop);
		memset(loop_ch, 0, MAX_BUFF);
		GetValue(TmpCGI, loop_ch, tmp, MAX_BUFF);

		if ( strlen(loop_ch) > 0 ) {
			strcat(options, loop_ch);
			strcat(options, " ");
		}
	}

#ifdef EZMLMIDX
	/* check for sql support */
	memset(tmp, 0, MAX_BUFF);
	GetValue(TmpCGI, tmp, "sqlsupport=", MAX_BUFF);
	if( strlen(tmp) > 0 ) {
		strcat(options, tmp);
		strcat(options, " ");
		for(loop = 0; loop < NUM_SQL_OPTIONS; loop++) {	
			sprintf(tmp, "sql%d=", loop+1);
			memset(loop_ch, 0, MAX_BUFF);
			GetValue(TmpCGI, loop_ch, tmp, MAX_BUFF);
			if ( strlen( loop_ch ) > 0 ) {
				strcat(options, loop_ch);
	    		if(loop < NUM_SQL_OPTIONS - 1) strcat(options, ":");
			}
		}
	}
#endif

	pid=fork();
	if (pid==0) {
		sprintf(TmpBuf1, "%s/ezmlm-make", EZMLMDIR);
		sprintf(TmpBuf2, "%s/%s", RealDir, ActionUser);
		sprintf(TmpBuf3, "%s/.qmail-%s", RealDir, ActionUser);
		i = 0;
		arguments[i++] = "ezmlm-make";

#ifdef EZMLMIDX
		if ( strlen(owneremail) > 0 ) arguments[i++]=owneremail;
#endif

		for(tmpstr=strtok(options," ");tmpstr!=NULL;tmpstr=strtok(NULL," ")){
			arguments[i++] = tmpstr;
		}
		arguments[i++]=TmpBuf2;
		arguments[i++]=TmpBuf3;
		arguments[i++]=ActionUser;
		arguments[i++]=Domain;
		arguments[i++]=NULL;

		execv(TmpBuf1, arguments);
		exit(127);
	} else {
		wait(&pid);
	}

	sprintf(TmpBuf, "%s/%s/inlocal",
		RealDir, ActionUser);

  	file=fopen(TmpBuf , "w");
	fprintf(file, "%s-%s", Domain, ActionUser);
	fclose(file);

	sprintf(StatusMessage, "%s %s@%s\n", get_html_text("226"), 
		ActionUser, Domain);
	show_mailing_lists(Username, Domain, Mytime);

}

