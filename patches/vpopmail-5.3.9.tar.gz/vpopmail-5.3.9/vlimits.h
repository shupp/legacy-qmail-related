/*
 * vlimits.h
 * handle domain limits in both file and mysql tables
 * Brian Kolaci <bk@galaxy.net>
 */

#ifndef VPOPMAIL_VLIMITS_H
#define VPOPMAIL_VLIMITS_H

struct vlimits {
      int       maxpopaccounts;
      int       maxaliases;
      int       maxforwards;
      int       maxautoresponders;
      int       maxmailinglists;
      int       diskquota;
      int       defaultquota;
      short     disablepop;
      short     disableimap;
      short     disabledialup;
      short     disablepasswordchanging;
      short     disablewebmail;
      short     disablerelay;
};

int vget_limits(char * domain, struct vlimits * limits);
int vset_limits(char * domain, struct vlimits * limits);
int vdel_limits(char * domain);

#endif
