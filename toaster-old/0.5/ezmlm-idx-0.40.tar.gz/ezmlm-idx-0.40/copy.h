#ifndef COPY_H
#define COPY_H

/* copy (qq,fn,fatal) */
extern void copy();
extern void set_cpoutlocal();
extern void set_cpouthost();
extern void set_cptarget();
extern void set_cpconfirm();
extern void set_cpnum();
#endif
