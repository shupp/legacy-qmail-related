
#ifndef IDXTHREAD_H
#define IDXTHREAD_H

/* threading */
extern void idx_mkthread();
extern void idx_mkthreads();
extern void idx_mklist();
extern void idx_destroythread();

#endif
