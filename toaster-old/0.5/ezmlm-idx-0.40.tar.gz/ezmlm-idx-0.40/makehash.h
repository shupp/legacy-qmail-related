#ifndef MAKEHASH_H
#define MAKEHASH_H

#define HASHLEN 20

extern void makehash();
extern void mkauthhash();

#endif

