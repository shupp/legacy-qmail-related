#ifndef AUTO_CRON_H
#define AUTO_CRON_H

extern char auto_cron[];

#endif
