/*
 * vaddomain
 * part of the vpopmail package
 * 
 * Copyright (C) 1999,2001 Inter7 Internet Technologies, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pwd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include "config.h"
#include "vpopmail.h"


#define MAX_BUFF 500

char Domain_old[MAX_BUFF];
char Domain_new[MAX_BUFF];
char TmpBuf1[MAX_BUFF];
char TmpBuf2[MAX_BUFF];

void usage();
void get_options(int argc,char **argv);

int main(argc,argv)
 int argc;
 char *argv[];
{
 char Dir[156];
 char *tmpstr;
 uid_t uid;
 gid_t gid;

	get_options(argc,argv);

	lowerit(Domain_old);
	lowerit(Domain_new);

	tmpstr = vget_assign(Domain_old, Dir, 156, &uid, &gid);
	if ( tmpstr == NULL ) {
		printf("existing domain %s not found\n", Domain_old);
		usage();
		vexit(0);
	}
	strncpy(TmpBuf1, Dir, MAX_BUFF);
	strncpy(TmpBuf2, Dir, MAX_BUFF);

	tmpstr = strstr(TmpBuf2, Domain_old);
	*tmpstr = 0;
        strncat( TmpBuf2, Domain_new, MAX_BUFF);

	if ( symlink(TmpBuf1, TmpBuf2) != 0 ) {
		fprintf(stderr, "Could not make link\n");
		perror("making link");
	}
	add_domain_assign( Domain_new, TmpBuf2, uid, gid );
	signal_process("qmail-send", SIGHUP);

	return(vexit(0));
}

void usage()
{
	printf("vaddaliasdomain: usage: [options] new_domain old_domain\n");
	printf("options: -v (print version number)\n");
}

void get_options(int argc,char **argv)
{
 int c;
 int errflag;

	memset(Domain_old, 0, MAX_BUFF);
	memset(Domain_new, 0, MAX_BUFF);
	memset(TmpBuf1, 0, MAX_BUFF);
	memset(TmpBuf2, 0, MAX_BUFF);

	errflag = 0;
    while( !errflag && (c=getopt(argc,argv,"v")) != -1 ) {
		switch(c) {
			case 'v':
				printf("version: %s\n", VERSION);
				break;
			default:
				errflag = 1;
				break;
		}
	}

	if ( optind < argc ) { 
		strncpy(Domain_new, argv[optind], MAX_BUFF); 
		++optind;
	}

	if ( optind < argc ) {
		strncpy(Domain_old, argv[optind], MAX_BUFF);
		++optind;
	}

	if ( Domain_new[0] == 0 || Domain_old[0] == 0 ) { 
		usage();
		vexit(-1);
	}
}
