#ifndef VPOPMAIL_LDAP_H
#define VPOPMAIL_LDAP_H

#undef OLD_VLDAP

#define VLDAP_SERVER "localhost"
#define VLDAP_PORT LDAP_PORT
#define VLDAP_USER "cn=Manager, o=Inter7"
#define VLDAP_PASSWORD "bumbum"

#ifdef OLD_VLDAP
   #define VLDAP_BASEDN "ou=Subs, o=Inter7"
#else
   #define VLDAP_BASEDN "ou=%s, o=Inter7"
#endif

static char *vldap_attrs[] = {
  "name",
  "uid",
  "qmailGID",
  "qmailUID",
  "qmaildomain",
  "userPassword",
  "mailQuota",
  "mailMessageStore",  
  NULL
};
#endif
