./configure \
 --enable-auth-logging=y \
