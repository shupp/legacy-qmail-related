<?php
require_once( "LanguageZh_cn.php");

class LanguageZh_sg extends LanguageZh_cn { 
# Inherit everything for now
}
?>
