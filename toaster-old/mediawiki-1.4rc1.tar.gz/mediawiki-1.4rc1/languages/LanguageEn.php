<?php
# See language.doc

require_once( 'LanguageUtf8.php' );

class LanguageEn extends LanguageUtf8 {
	# Inherit everything
}

?>
