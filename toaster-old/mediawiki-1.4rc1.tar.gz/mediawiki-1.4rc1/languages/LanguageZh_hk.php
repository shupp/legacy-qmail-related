<?php
require_once( "LanguageZh_tw.php");

class LanguageZh_hk extends LanguageZh_tw { 
# Inherit everything for now
}
?>