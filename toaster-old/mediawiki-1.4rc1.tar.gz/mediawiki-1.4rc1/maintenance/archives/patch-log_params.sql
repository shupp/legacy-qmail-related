ALTER TABLE /*$wgDBprefix*/logging ADD log_params blob NOT NULL default '';
