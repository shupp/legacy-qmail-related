<?php
   /*
    *  quota_usage
    *  By Bill Shupp <hostmaster@shupp.org>
    *  (c) 2001 (GNU GPL - see ../../COPYING)
    *
    */

   function squirrelmail_plugin_init_quota_usage() {
       global $squirrelmail_plugin_hooks;
       $squirrelmail_plugin_hooks["left_main_before"]["quota_usage"] = "display_quota_usage_left";
   }

   function display_quota_usage_left() {
      global $username, $key, $imapServerAddress, $imapPort, $imap,
         $imap_general, $filters, $imap_stream, $imapConnection, 
         $UseSeparateImapConnection;

      // Detect if we have already connected to IMAP or not.
      // Also check if we are forced to use a separate IMAP connection
      if ((!isset($imap_stream) && !isset($imapConnection)) ||
          $UseSeparateImapConnection) {
         $stream = sqimap_login($username, $key, $imapServerAddress, 
            $imapPort, 10);
         $previously_connected = false;
      } elseif (isset($imapConnection)) {
         $stream = $imapConnection;
         $previously_connected = true;
      } else {
         $previously_connected = true;
         $stream = $imap_stream;
      }

      $usage = sqimap_get_quota($stream, "INBOX");
      if(!ereg("NOQUOTA", $usage)) {
         echo "<center><font size=-2>current usage:<br>\n";
         echo "<b>".ereg_replace(":.*$", "", $usage)."% of ".ereg_replace("^.*:", "", $usage)." MB</b>\n";
         echo "</font></center><p>\n";
      }
      
      if (!$previously_connected)
         sqimap_logout($stream);

   }

   /******************************************************************************
    **  Gets current quota usage
    ******************************************************************************/
   function sqimap_get_quota ($imap_stream, $mailbox) {
      if (sqimap_capability($imap_stream, "QUOTA") == "QUOTA") {
        fputs ($imap_stream, "a001 GETQUOTAROOT \"$mailbox\"\r\n");
        $read_ary = sqimap_read_data ($imap_stream, 'a001', true, $result, $message);
        for ($i = 0; $i < count($read_ary); $i++) {
            if (ereg("STORAGE", $read_ary[$i])) {
                $tempusage = ereg_replace("^.*[(]STORAGE +(.*)[)].*$", "\\1", $read_ary[$i]);
                $usagearray = explode(" ", $tempusage);
                $num0 = $usagearray[0];
                $num1 = $usagearray[1];
                $percent = ($num0/$num1) * 100;
                $quota = (($num1 *1024) - 1023) / 1000000;

                return number_format($percent, 1).":".number_format($quota, 1);
            }
        }
      }
      return "NOQUOTA";
   }

?>
