./configure \
 --enable-roaming-users=y \
 --enable-file-sync=n \
 --enable-auth-logging=y \
